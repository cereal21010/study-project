import Vue from "vue";

// plugin setup
import {BootstrapVue, IconsPlugin} from "bootstrap-vue";
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.use(BootstrapVue)
Vue.use(IconsPlugin)


const GlobalComponents = {
    install(Vue, options) {

        /*Vue.component(WDCheckBox.name, WDCheckBox);
        Vue.component(WDInput.name, WDInput);
        Vue.component(WDNumberInput.name, WDNumberInput);
        Vue.component(WDSelectBox.name, WDSelectBox);
        Vue.component(WDRadioGroup.name, WDRadioGroup);
        Vue.component(WDModal.name, WDModal);
        Vue.prototype.$showAlert = function({title, content, callback}){
          EventBus.$emit("@showAlert", {title, content, callback});
        }
        Vue.prototype.$showConfirm = function({title, content, callback, cancelBtnName}){
          EventBus.$emit("@showConfirm", {title, content, callback, cancelBtnName});
        }
        Vue.prototype.$showLoading = function(  ){
          EventBus.$emit("@showLoading" );
        }
        Vue.prototype.$hideLoading = function(){
          EventBus.$emit("@hideLoading" );
        }*/

        Vue.prototype.$setDataAttributes = function ( target, src ) {
            Object.keys(src).forEach(function(key) {
                Vue.set(target, key, src[key]); // 또는
            })
        }
        Vue.prototype.$setDataAttribute = function ( target, key, val ) {
            Vue.set(target, key, val); // 또는
        }
    }
};

Vue.use(GlobalComponents);

export default GlobalComponents;
