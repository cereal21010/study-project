/*
- 작성: 윈드폴
- 목적: vue 컴포넌트 관리
*/
/*전역컴퍼넌트 Start*/
//레이아웃
import Vue from "vue";

import DefaultLayout from "../views/layout/DefaultLayout";
import FlatLayout from "../views/layout/FlatLayout";

Vue.component('DefaultLayout', DefaultLayout);
Vue.component('FlatLayout', FlatLayout);
