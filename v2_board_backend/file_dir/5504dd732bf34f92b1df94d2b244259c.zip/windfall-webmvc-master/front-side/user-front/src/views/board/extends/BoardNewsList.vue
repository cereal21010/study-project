<template>
    <div class="hello">
        <H1>
            뉴스 위한 목록 페이지
        </H1>

        <ul>
            <li v-for="item in boardList">
                {{ item.title }}
            </li>
        </ul>

        <b-pagination
                :value="searchParam.page"
                :per-page="searchParam.perPage"

                :total-rows="pagination.totalCount"
                @change="gotoPage"
        />

        <p @click="gotoWrite">
            Write
        </p>

    </div>
</template>


<script>

import BoardList from "@/views/board/BoardList";

export default {
    name: 'BoardNewsList',
    extends: BoardList
}
</script>

<style>
</style>
