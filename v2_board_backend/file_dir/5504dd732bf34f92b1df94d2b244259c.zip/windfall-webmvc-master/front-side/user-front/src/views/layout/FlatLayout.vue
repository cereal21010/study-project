<template>
    <div class="wrapper">
        <div class="main-content">
            <!-- content -->
            <transition name="custom-slide-left"
                        mode="out-in">
                <router-view/>
            </transition>
        </div>
    </div>
</template>

<script>

    import WDNavBar from "./WDNavBar";
    import Footer from "./WDFooter";

    export default {
        components: {
            WDNavBar,
            Footer,
        },
        methods: {
        }
    };
</script>
