<template>
    <div class="wrapper">
        <div class="main-content">
            <!-- common menu -->
            <WDNavBar ref="navBar" />

            <!-- content -->
            <transition name="custom-slide-left"
                        mode="out-in">
                <router-view/>
            </transition>

            <Footer />
        </div>
    </div>
</template>

<script>

    import WDNavBar from "./WDNavBar";
    import Footer from "./WDFooter";

    export default {
        components: {
            WDNavBar,
            Footer,
        },
        methods: {
        }
    };
</script>
