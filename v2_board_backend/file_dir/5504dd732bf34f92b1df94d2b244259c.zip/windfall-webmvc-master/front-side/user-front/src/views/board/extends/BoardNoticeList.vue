<template>
    <div class="hello">
        <H1>
            공지사항을 위한 목록 페이지
        </H1>

        <b-container fluid>
            <b-row>
                <b-col sm="3">
                    <label>제목</label>
                    <b-form-input type="text" v-model="searchParam.title"/>
                </b-col>
                <b-col sm="3">
                    <label>내용</label>
                    <b-form-input type="text" v-model="searchParam.contents"/>
                </b-col>
                <b-col sm="3">
                    <label>저자</label>
                    <b-form-input type="text" v-model="searchParam.author"/>
                </b-col>
                <b-col sm="3">
                    <b-button @click="doSearch" >
                        검색
                    </b-button>
                </b-col>
            </b-row>

            <b-row>
                <b-col sm="3"></b-col>
                <b-col sm="3"></b-col>
                <b-col sm="3">
                    order by
                    <b-form-select v-model="searchParam.orderBy"
                                   :options="optionOrderBy"
                                   @change="doSearch"
                                   size="sm"
                    />
                    <b-form-select v-model="searchParam.orderDir"
                                   :options="optionOrderDir"
                                   @change="doSearch"
                                   size="sm"
                    />
                </b-col>
                <b-col sm="3">
                    per-page
                    <b-form-select v-model="searchParam.perPage"
                                   :options="optionPerPage"
                                   @change="doSearch"
                                   size="sm"
                    />
                </b-col>
            </b-row>

        </b-container>


        <b-table
                :items="boardList"
                @row-clicked="gotoView"
        />

        <b-pagination
                :value="searchParam.page"
                :per-page="searchParam.perPage"

                :total-rows="pagination.totalCount"
                @change="gotoPage"
        />

        <p @click="gotoWrite">
            Write
        </p>

    </div>
</template>


<script>

import BoardList from "@/views/board/BoardList";

export default {
    name: 'BoardNoticeList',
    extends: BoardList
}
</script>

<style>
</style>
