<!--
    용도: 공통 메뉴 바
-->
<template>
    <div>
        Header
    </div>
</template>

<script>
import {mapMutations} from "vuex";

export default {
    name: "WDNavBar",
    components: {
    },

    computed: {
    },
    data(){
        return {
        }
    },
    watch: {
    },

    methods: {
    },
    created() {
    },
    mounted() {
    },
}


</script>

<style scoped>

</style>
