<template>
    <div class="hello">
        This is update.
    </div>
</template>

<script>
export default {
    name: 'BoardUpdate',
    props: {
    }
}
</script>

<style >
</style>
