<template>
    <div class="hello">
        This is view.
        <p>
            제목: {{ boardDetail.title }}
        </p>
        <p>
            내용: {{ boardDetail.contents }}
        </p>
        <p>
            저자: {{ boardDetail.author }}
        </p>


        <div>
            <button @click="gotoUpdate">
                수정
            </button>
            <button @click="gotoList">
                목록
            </button>
        </div>
    </div>
</template>

<script>
import CommonUtil from "@/utils/CommonUtil";

export default {
    name: 'BoardView',
    props: {
        boardCode: {
            type: String,
            required: true
        },
        boardPath:{
            type: String,
            required: true
        },
        query: {
            type: Object,
            default: () => {
            }
        },
        seq: {
            type: String,
            required:true
        },
    },
    inject: ['boardService'],
    components: {},
    data(){
        return {
            boardDetail:{}
        }
    },
    computed: {},
    created() {},
    async mounted () {

        //TODO: 검색 쿼리 파라미터 세팅.
        const searchParam = {};
        const detail = await this.boardService.getBoardDetail(this.boardCode,  this.seq );
        this.$setDataAttributes( this.boardDetail, detail);
        // console.log(this.boardDetail)
    },
    methods:{
        gotoUpdate(){
            this.$router.push({
                path: `${this.boardPath}/update/${this.seq}`,
                query: this.query
            })
        },
        gotoList(){
            this.$router.push({
                path: `${this.boardPath}/list`,
                query: this.query
            })
        }
    }
}
</script>

<style >
</style>
