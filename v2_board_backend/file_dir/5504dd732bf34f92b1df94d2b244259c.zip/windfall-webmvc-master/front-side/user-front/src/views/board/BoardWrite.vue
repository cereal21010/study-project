<template>
    <b-container fluid>
        <b-row>
            <b-col sm="3">
                <label>제목</label>
            </b-col>
            <b-col sm="9">
                <b-form-input type="text" v-model="boardDetail.title"></b-form-input>
            </b-col>
        </b-row>

        <b-row>
            <b-col sm="3">
                <label>작성자</label>
            </b-col>
            <b-col sm="9">
                <b-form-input type="text" v-model="boardDetail.author"></b-form-input>
            </b-col>
        </b-row>

        <b-row>
            <b-col sm="3">
                <label>비밀번호</label>
            </b-col>
            <b-col sm="9">
                <b-form-input type="password" v-model="boardDetail.passwd"></b-form-input>
            </b-col>
        </b-row>

        <b-row>
            <b-col sm="3">
                <label>내용</label>
            </b-col>
            <b-col sm="9">
                <b-form-textarea
                    id="textarea"
                    v-model="boardDetail.contents"
                    placeholder="Enter something..."
                    rows="3"
                    max-rows="6"
                ></b-form-textarea>
            </b-col>
        </b-row>



        <b-row v-for="uploadFieldConfig in this.uploadFieldConfigs">
            <b-col sm="3">
                <label>{{ uploadFieldConfig.label }}</label>
            </b-col>
            <b-col sm="9">

                <b-form-file v-if="uploadFieldConfig.multiple === 1"
                             v-model="uploadFiles[uploadFieldConfig.fieldName]"
                             :state="Boolean( uploadFiles[uploadFieldConfig.fieldName] )"
                             placeholder="Choose a file or drop it here..."
                             drop-placeholder="Drop file here..."
                ></b-form-file>

                <b-form-file v-else
                             v-model="uploadFiles[uploadFieldConfig.fieldName]"
                             multiple>
                    <template slot="file-name" slot-scope="{ names }">
                        <b-badge variant="dark">{{ names[0] }}</b-badge>
                        <b-badge v-if="names.length > 1" variant="dark" class="ml-1">
                            + {{ names.length - 1 }} More files
                        </b-badge>
                    </template>
                </b-form-file>
            </b-col>
        </b-row>


        <b-row>
            <button @click="save">SUBMIT</button>
        </b-row>


    </b-container>

</template>

<script>
export default {
    name: 'BoardWrite',
    props: {
        boardCode: {
            type: String,
            required: true
        },
        boardPath: {
            type: String,
            required: true
        },
        uploadFieldConfigs:{
            type:Array,
            default: () => []
        },
        query: {
            type: Object,
            default: () => {}
        },
    },
    inject: ['boardService'],
    components: {},
    data() {
        return {
            boardDetail: {
                title: '',
                contents: '',
                passwd: '',
                author: '',
            },
            // props 값 uploadFieldConfigs 에 의해 설정됨.
            uploadFiles: {
            }
        }
    },
    computed: {},
    created() {
        //첨부파일 정보 세팅
        this.uploadFieldConfigs.forEach((config)=>{
            this.$setDataAttribute( this.uploadFiles, config.fieldName, null );
        })
    },
    async mounted() {
        console.log('write ', this.uploadFieldConfigs)
    },
    methods: {

        save() {
            this.boardService.insertBoard(this.boardCode, this.boardDetail, this.uploadFiles);
            return false;
        }
    }
}
</script>

<style>
</style>
