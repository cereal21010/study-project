
<template>
    <footer class="footer"/>
</template>

<script>
    export default {
        name: "WDFooter",
    }
</script>

<style scoped>

</style>
