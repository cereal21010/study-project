import axios from '@/utils/AxiosInterceptors'

export class BoardService {

    constructor(host) {
        this.host = host;
    }

    getBoardList( boardCode, params ){
        console.log( `getBoardList::${boardCode}`, params );

        return axios
            .get(`${this.host}/api/board/${boardCode}`, {params:params})
            .then(response => {
                // console.log('>>== response', response);
                return response.data.response;
            })
            .catch((e) => { console.log(e); });
            ;
    }

    getBoardDetail( boardCode, seq ){
        console.log( `getBoardList::${boardCode}::${seq}`, params );

        const params = {};
        return axios
            .get(`${this.host}/api/board/${boardCode}/${seq}`, {params:params})
            .then(response => {
                // console.log('>>== response', response);
                return response.data.response;
            })
            .catch((e) => { console.log(e); });
        ;
    }

    buildJsonBlob( jsonObj ){
        const json = JSON.stringify(jsonObj );
        const blob = new Blob([json], {
            type: 'application/json'
        });
        return blob;
    }

    insertBoard(boardCode, boardDetail, uploadFiles) {

        const formData = new FormData();

        // const fileFields = [];
        formData.append('mainImage', uploadFiles.mainImage);
        formData.append('subImage', uploadFiles.subImage);
        // formData.append('subImage', boardDetail.subImage);

        //첨부 제외
        // const requestBody = _.omit(boardDetail, ['mainImage','subImage']);
        // const json = JSON.stringify(requestBody );
        // const blob = new Blob([json], {
        //     type: 'application/json'
        // });
        const requestBody = _.omit(boardDetail, ['mainImage','subImage']);
        formData.append('requestBody', this.buildJsonBlob(requestBody) );

        const params = {};
        //TODO: inject boardCode to path

        return axios
            .post(`${this.host}/api/board/${boardCode}`, formData, {
                headers: {
                    'Content-Type': 'multipart/mixed'
                }})
            .then(response => {
                console.log('>>== response', response);
                return response.data.response;
            })
            .catch((e) => { console.log(e); });
        ;
    }



}


//== mockup
export class MockAccountService {

    constructor(host) {
        this.host = host;
    }

}
