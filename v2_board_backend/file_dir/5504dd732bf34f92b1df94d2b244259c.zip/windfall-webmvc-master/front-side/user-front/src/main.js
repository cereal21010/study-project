import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import "./plugins/filters"
import "./plugins/inject-layout"
import "./plugins/global-components"
import {BoardService} from "@/services/BoardService";



Vue.config.productionTip = false

const API_URL_HOST = process.env.VUE_APP_API_HOST;


new Vue({
  router,
  store,
  provide: {
    boardService: new BoardService(API_URL_HOST),
  },
  render: h => h(App)
}).$mount('#app')
