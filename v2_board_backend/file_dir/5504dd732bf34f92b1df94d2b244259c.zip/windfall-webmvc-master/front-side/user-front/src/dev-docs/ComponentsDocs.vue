<template>
    <div>

        Samples.

    </div>
</template>

<script>
export default {
    name: 'ComponentsDocs',
    props: {
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
</style>
