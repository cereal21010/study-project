import BoardContainer from "@/views/board/BoardContainer";
import BoardList from "@/views/board/BoardList";
import BoardView from "@/views/board/BoardView";
import BoardWrite from "@/views/board/BoardWrite";
import BoardUpdate from "@/views/board/BoardUpdate";
import BoardNoticeList from "@/views/board/extends/BoardNoticeList";
import BoardNewsList from "@/views/board/extends/BoardNewsList";
import ComponentsDocs from "@/dev-docs/ComponentsDocs";



const devRoutes = [
    {
        path: '/dev',
        redirect: '/dev/components',
    },
    {
        path: '/dev/components',
        component: ComponentsDocs,
    },

]

export default devRoutes
