import BoardContainer from "@/views/board/BoardContainer";
import BoardList from "@/views/board/BoardList";
import BoardView from "@/views/board/BoardView";
import BoardWrite from "@/views/board/BoardWrite";
import BoardUpdate from "@/views/board/BoardUpdate";
import BoardNoticeList from "@/views/board/extends/BoardNoticeList";
import BoardNewsList from "@/views/board/extends/BoardNewsList";


const boardProps = (route) => {
    const props =  {
        boardPath: route.matched[0].path
    }
    _.merge(props, route.params, route.matched[0].props.default);
    props.query = route.query;
    console.log('boardProps', props)
    return props;
};


const boardRoutes = [

    {
        /* 자유게시판 */
        path: '/board/free/',
        component: BoardContainer,
        props: {
            boardCode: 'free',
            title: '자유게시판',
            uploadFieldConfigs:[
                {fieldName:'mainImage', label:'메인이미지', multiple:1},
                {fieldName:'subImage', label:'서브이미지',  multiple:1},
                {fieldName:'attaches', label:'첨부들',  multiple:10}
            ],
        },
        children: [
            {
                path: 'list',
                component: BoardList,
                props: boardProps,
            },
            {
                path: 'view/:seq',
                component: BoardView,
                props: boardProps,
            },
            {
                path: 'write',
                component: BoardWrite,
                props: boardProps,
            },
            {
                path: 'update/:seq',
                component: BoardUpdate,
                props: boardProps,
            }
        ]
    },
    {
        /* 공지사항 */
        path: '/board/notice/',
        component: BoardContainer,
        props: {
            boardCode: 'notice',
            title: '공지사항',
        },
        children: [
            {
                path: 'list',
                component: BoardNoticeList,
                props: boardProps,
            },
            {
                path: 'view/:seq',
                component: BoardView,
                props: boardProps,
            },
            {
                path: 'write',
                component: BoardWrite,
                props: boardProps,
            },
            {
                path: 'update/:seq',
                component: BoardUpdate,
                props: boardProps,
            }
        ]
    },
    {
        /* 뉴스 */
        path: '/board/news/',
        component: BoardContainer,
        props: {
            boardCode: 'news',
            title: '뉴스',
        },
        children: [
            {
                path: 'list',
                component: BoardNewsList,
                props: boardProps,
            },
            {
                path: 'view/:seq',
                component: BoardView,
                props: boardProps,
            },
            {
                path: 'write',
                component: BoardWrite,
                props: boardProps,
            },
            {
                path: 'update/:seq',
                component: BoardUpdate,
                props: boardProps,
            }
        ]
    }

]

export default boardRoutes
