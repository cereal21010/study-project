import Vue from 'vue'
import _ from 'lodash';


const _validate = (options, rule, errorBack) => {
    switch (rule) {
        case 'required' :
            if(!options.value){
                errorBack.push(`${options.label}을/를 입력해 주세요.`);
            }

            if (_.isString(options.value) && options.value === '') {
                errorBack.push(`${options.label} 필수값입니다.`);
            }

            if (_.isArray(options.value) && options.value.length === 0) {
                errorBack.push(`${options.label} 필수값입니다.`);
            }
            break;
        case 'email' :
            var pattern = /^(?:[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
            if(!pattern.test(options.value)){
                errorBack.push(`${options.label} 형식이 아닙니다.`);
            }
            break;
        case 'only-number' :
            var pattern = /[0-9]/;
            if(!pattern.test(options.value)){
                errorBack.push(`${options.label} 숫자만 입력 가능합니다.`);
            }
            break;
        case 'only-eng' :
            var pattern = /[a-zA-Z]/;
            if(!pattern.test(options.value)){
                errorBack.push(`${options.label} 영문만 입력 가능합니다.`);
            }
            break;
        case 'only-kor' :
            var pattern = /[가-힣]/;
            if(!pattern.test(options.value)){
                errorBack.push(`${options.label} 한글만 입력 가능합니다.`);
            }
            break;
        case 'pwd' :
            var pattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;//숫자, 문자, 8자리
            //var pattern2 = /[~!@#$%^&*()_+|<>?:{}]/;
            //if(!pattern.test(options.value) || !pattern2.test(options.value)){
            if(!pattern.test(options.value)){
                errorBack.push(`${options.label} 숫자, 문자 포함한 최소 8자리 이내로 입력해 주세요`);
            }
            break;
        case 'hp' :
            var pattern = /^\d{3}-\d{3,4}-\d{4}$/;
            if(!pattern.test(options.value)){
                errorBack.push(`${options.label} 형식이 아닙니다.`);
            }
            break;
        case 'telno' :
            var pattern = /^\d{2,3}-\d{3,4}-\d{4}$/;
            if(!pattern.test(options.value)){
                errorBack.push(`${options.label} 형식이 아닙니다.`);
            }
            break;
        case 'custom' :
            const isValid = options.customValidate();
            console.log(isValid);
            if(!isValid){
                errorBack.push(`${options.label} ${options.customText}`);
            }
            break;
    }
}

const validComponent = Vue.component('ValidError', {
    template: '<div class="invalid-feedback" style="display: block;" v-show="error">{{ error }}</div>',
    data: function () {
        return {
            error: '',
            errorBack: [],
        }
    },
    methods:{
        validate(options, rules){
            this.errorBack = [];
            rules.forEach((rule) => {
                _validate(options, rule, this.errorBack);
            });
            if(this.errorBack.length > 0 ) {
                this.error = this.errorBack[0];
            }else{
                this.error = '';
            }
        },
        pushError(error){
            this.errorBack.push(error);
            if(this.errorBack.length > 0 ) {
                this.error = this.errorBack[0];
            }else{
                this.error = '';
            }
        },
        getError(){
            return this.errorBack[0];
        }
    },
});

const state = new WeakMap();
const elList = [];
const validObjMap = new WeakMap();

export default {
    inserted: (el, binding, vnode) => {
        const validComponentMount = new validComponent().$mount();
        state.set(el, validComponentMount);
        el.after(validComponentMount.$el);
        elList.push(el);
        validObjMap.set(el, {
            value: binding.value,
            rules: Object.keys(binding.modifiers)
        });

        const rules = Object.keys(binding.modifiers);
        el.addEventListener('focusout', () => {
            if(rules.length > 0){
                validComponentMount.validate(binding.value, rules);
                if(validComponentMount.getError()){
                    if(el.getElementsByTagName("input")[0]) {
                        el.getElementsByTagName("input")[0].classList.add('input-valid-error');
                    }
                }else{
                    if(el.getElementsByTagName("input")[0]) {
                        el.getElementsByTagName("input")[0].classList.remove('input-valid-error');
                    }
                }
            }
        },{
            once : true
        });
    },
    update: (el, binding, vnode) => {
        const validComponentMount = state.get(el);
        const rules = Object.keys(binding.modifiers);

        validObjMap.set(el, {
            value: binding.value,
            rules: Object.keys(binding.modifiers)
        });

        ['input', 'focusout', 'focusin', 'change'].forEach((event) => {
            el.addEventListener(event, () => {
                if(rules.length > 0){
                    validComponentMount.validate(binding.value, rules);
                    if(validComponentMount.getError()){
                        if(el.getElementsByTagName("input")[0]) {
                            el.getElementsByTagName("input")[0].classList.add('input-valid-error');
                        }
                    }else{
                        if(el.getElementsByTagName("input")[0]) {
                            el.getElementsByTagName("input")[0].classList.remove('input-valid-error');
                        }
                    }
                }
            },{
                once : true
            });
        });



        /*el.addEventListener('focusout', () => {
            if(rules.length > 0){
                validComponentMount.validate(binding.value, rules);
                if(validComponentMount.getError()){
                    el.getElementsByTagName("input")[0].classList.add('input-valid-error');
                }else{
                    el.getElementsByTagName("input")[0].classList.remove('input-valid-error');
                }
            }
        },{
            once : true
        });*/
    },
    unbind(el) {
        state.delete(el);
        validObjMap.delete(el);
        _.remove(elList, (_el)=>{
            return el === _el;
        });
    }
}

export const validateAll = () => {
    elList.forEach((el) => {
        const validComponentMount = state.get(el);
        const validObj = validObjMap.get(el);
        const rules =  validObj.rules;
        const value =  validObj.value;
        validComponentMount.validate(value, rules);
        if(validComponentMount.getError()){
            el.getElementsByTagName("input")[0] ? el.getElementsByTagName("input")[0].classList.add('input-valid-error') : '';
        }else{
            el.getElementsByTagName("input")[0] ? el.getElementsByTagName("input")[0].classList.remove('input-valid-error') : '';
        }
    });
}

export const validateByIndex = (index) => {
    const el = elList[index];
    const validComponentMount = state.get(el);
    const validObj = validObjMap.get(el);
    const rules =  validObj.rules;
    const value =  validObj.value;
    validComponentMount.validate(value, rules);
}

export const getErrorBack = () => {
    let errorList = [];
    elList.forEach((el) => {
        const validComponentMount = state.get(el);
        if(validComponentMount.getError()){
            errorList.push(validComponentMount.getError());
        }
    });

    return errorList;
}
