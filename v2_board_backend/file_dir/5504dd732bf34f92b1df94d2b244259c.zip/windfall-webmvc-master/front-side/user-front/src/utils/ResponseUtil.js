import moment from "moment";

export default {

    //== axios response: { data: { data:{}, resultCode:'', jwtToken:""...  }, config:{}, headers:{}...}

    /**
     * 서버에서 받을 result 형식: mockup 성공일 때
     */
    mockupResultSuccess(mockSuccessAccount, hasJwtToken = false) {
        let result = {resultCode: "SUCCESS", data: mockSuccessAccount, msg:''};
        if(hasJwtToken) {
            result.jwtToken = 'jwtHello1234';
        }
        return result;
    },

    /**
     * 서버에서 받을 result 형식: mockup 실패일 때
     */
    mockupResultFail(msg) {
        return {resultCode: "FAIL", data: '', jwtToken: '', msg: msg};
    },

    /**
     * 결과 성공했는지
     */
    isResultSuccess(result) {
        return result && result.resultCode === "SUCCESS";
    },

    /**
     * response data 가져옴
     */
    getData(result) {
        return result.data;
    },

    /**
     * jwt token
     */
    getJwtToken(result) {
        return result.jwtToken;
    },

    /**
     * regionList
     */
    getRegionList(result) {
        return result.regionList;
    },

    /**
     * response msg 가져옴
     */
    getMsg(result) {
        return result.msg;
    }


}

