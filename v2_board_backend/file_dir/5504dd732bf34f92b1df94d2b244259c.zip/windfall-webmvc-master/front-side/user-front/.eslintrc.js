const INLINE_ELEMENTS = [
    "a", "abbr", "audio", "b", "bdi", "bdo", "canvas", "cite", "code",
    "data", "del", "dfn", "em", "i", "iframe", "ins", "kbd", "label", "map", "mark", "noscript",
    "object", "output", "picture", "q", "ruby", "s", "samp", "small", "span", "strong", "sub", "sup",
    "svg", "time", "u", "var", "video", "p"
]


module.exports = {
    root: true,
    env: {
        node: true
    },
    extends: [
        'plugin:vue/base'
    ],
    plugins: [
        'html',
        'vue',
    ],
    ignorePatterns: ["**/argon-template/*"],
    rules: {
        'no-console': process.env.NODE_ENV === 'production' ? 'warn' : 'off',
        'no-debugger': process.env.NODE_ENV === 'production' ? 'warn' : 'off',

        /** 컴퍼넌트 명칭 파스칼 케이스 **/
        "vue/component-definition-name-casing": ["warn", "PascalCase"],

        /** prop 명칭 카멜 케이스 **/
        "vue/prop-name-casing": ["warn", "camelCase"],

        /**  **/
        "vue/html-closing-bracket-newline": [1, {
            "singleline": "never",
            "multiline": "never"
        }],

        /** html 더블컴마 **/
        "vue/html-quotes": ["warn", "double"],

        /** html 들여쓰기 **/
        "vue/html-indent": [1, 4, {
            "attribute": 2,
            "baseIndent": 1,
            "closeBracket": 0,
            "alignAttributesVertically": true,
            "ignores": []
        }],

        /** html 싱글태그 **/
        "vue/html-self-closing": ["warn", {
            "html": {
                "void": "never",
                "normal": "always",
                "component": "always"
            },
            "svg": "always",
            "math": "always"
        }],

        /** html 속성 두개 이상인 경우 개행 **/
        "vue/max-attributes-per-line": ["warn", {
            "singleline": 2,
            "multiline": {
                "max": 1,
                "allowFirstLine": true
            }
        }],

        /** html 태그 안에 내용 개행 필요 **/
        "vue/multiline-html-element-content-newline": ["warn", {
            "ignoreWhenEmpty": true,
            "ignores": ["pre", "textarea", ...INLINE_ELEMENTS],
            "allowEmptyLines": false
        }],

        /** 콧수염 보간안에 여백이 존제해야함**/
        "vue/mustache-interpolation-spacing": ["warn", "always"],

        /** html 불필요한 공백 **/
        "vue/no-multi-spaces": ["warn", {
            "ignoreProperties": false
        }],

        /** html 속성 등호 사이에는 공백 없어야함**/
        "vue/no-spaces-around-equal-signs-in-attribute": ["warn"],

        /** props 정의시 필수가 아닌경우는 디폴트값 필요 **/
        "vue/require-default-prop": ["warn"],

        /** props 정의시 타입이 필요 **/
        "vue/require-prop-types": ["warn"],

        /** 태그 간 개행 필요**/
        /*"vue/singleline-html-element-content-newline": ["warn", {
            "ignoreWhenNoAttributes": true,
            "ignoreWhenEmpty": true,
            "ignores": ["pre", "textarea", ...INLINE_ELEMENTS]
        }],*/

        /** v-bind 대신 : 사용 **/
        "vue/v-bind-style": ["warn", "shorthand"],

        /** v-on 대신 @ 사용**/
        "vue/v-on-style": ["warn", "shorthand"],

        /** html 안에서 this 사용금지**/
        "vue/this-in-template": ["warn", "never"],

        /** html 안에서 컴퍼넌트 명칭은 파스칼케이스로**/
        "vue/component-name-in-template-casing": ["warn", "PascalCase", {
            "registeredComponentsOnly": true,

        }],

        /** 컴퍼넌트 이름 정의시 뷰파일 명과 동일해야함 **/
        "vue/match-component-file-name": ["error", {
            "extensions": ["vue"],
            "shouldMatchCase": true
        }],

        /** vue 속성명 오타 체크 **/
        "vue/no-potential-component-option-typo": ["warn", {
            "presets": ["vue", "vue-router"],
            "custom": ["test"]
        }]
    },
    parserOptions: {
        parser: 'babel-eslint'
    }
};
