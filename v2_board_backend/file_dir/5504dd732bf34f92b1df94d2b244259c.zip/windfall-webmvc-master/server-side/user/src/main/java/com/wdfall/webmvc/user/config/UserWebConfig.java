package com.wdfall.webmvc.user.config;

import com.wdfall.webmvc.user.interceptor.TokenInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
@EnableWebMvc
@Profile("!test")
public class UserWebConfig implements WebMvcConfigurer {

    /**
     * CORS 필터 적용
     * @param registry
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") //모든 요청에 대해서
                .allowedOrigins("*"); //허용할 오리진들
    }


    /**
     * 정적 자원처리
     * @param registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("assets/**")
                .addResourceLocations("/assets/");

        registry.addResourceHandler("favicon.ico")
                .addResourceLocations("/");
    }


    /**
     * SpringBoot에서의 인터셉터는 @Autowired 를 사용하기 위해서 필요
     * @return
     */
    @Bean
    TokenInterceptor tokenInterceptor() {
        return new TokenInterceptor();
    }

    /**
     * 인터셉터 추가
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        // test: 개발시 interceptor 먼저 사용안함
        boolean isTest = true;
        if(true) {
            return;
        }

        registry.addInterceptor(tokenInterceptor())
                /* ----예외 케이스----
                 * 로그인(AuthController)
                 * 로그인검증(AuthController)
                 * 일반에러
                 * api에러(ExceptionController)
                 */
                .excludePathPatterns(
                        "/api/auth/login"
                        , "/error"
                        , "/api/exception/**"
                );
    }


}
