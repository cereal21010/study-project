package com.wdfall.webmvc.user.interceptor;

import com.wdfall.webmvc.common.token.TokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 사용자 인터셉터
 */
@Slf4j
public class TokenInterceptor extends HandlerInterceptorAdapter {

    /**
     * 토큰발행 / 검증 서비스
     */
    @Autowired
    private TokenService tokenService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler) throws Exception {

        log.debug("TokenInterceptor accept ["+request.getRequestURI()+"]");

        tokenService.checkTokenNew(); // GlobalException에서 VAuthException 받을수 있음.
        return true;

    }


}
