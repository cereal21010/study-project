package com.wdfall.webmvc.user.controller.board;

import com.wdfall.webmvc.common.APIResponseBuilder;
import com.wdfall.webmvc.common.domains.board.BoardSearchCondition;
import com.wdfall.webmvc.common.domains.board.BoardService;
import com.wdfall.webmvc.common.domains.board.BoardVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.util.List;

/**
 * 자유게시판
 */
@RestController
@Slf4j
public class BoardNewsController {

    @Autowired @Qualifier("boardNoticeService")
    BoardService boardService;

    /**
     * 글 목록 조회
     * @param search
     * @return
     */
    @RequestMapping(value = "/api/board/news", method = RequestMethod.GET)
    public ResponseEntity<?> getList(BoardSearchCondition search) {

        List<BoardVO> boardList = boardService.getBoardList(search);
        APIResponseBuilder success = APIResponseBuilder.success();
        success.putValue("search", search );
        success.putValue("rows", boardList );
        return success.build();
    }

    /**
     * 글 조회
     * @param seq
     * @return
     */
    @RequestMapping(value = "/api/board/news/{seq}", method = RequestMethod.GET)
    public ResponseEntity<?> getOne(@PathVariable("seq") int seq) {

        BoardVO board = boardService.getBoard(seq);
        if( board == null ){
            throw new RuntimeException("Cannot find board");
        }

        boardService.increaseViewCount(seq);
        return APIResponseBuilder.success(board).build();
    }

    /**
     * 글 삭제
     * @param seq
     * @return
     */
    @RequestMapping(value = "/api/board/news/{seq}", method = RequestMethod.DELETE)
    public ResponseEntity<?> deleteOne(@PathVariable("seq") int seq) {

        boardService.deleteBoard(seq);

        return APIResponseBuilder.success().build();
    }

    /**
     * 글 등록
     * @param board
     * @param bindingResult
     * @return
     */
    @RequestMapping(value = "/api/board/news", method = RequestMethod.POST )
    public ResponseEntity<?> insertData(@RequestPart("requestBody") BoardVO board,
                                        MultipartHttpServletRequest request,
                                        BindingResult bindingResult) {

        //글 내용 등록
        boardService.insertBoard(board);

        // handle upload files
        boardService.storeFiles( board.getSeq(), request.getMultiFileMap() );

        return  APIResponseBuilder.success(board).build();
    }


    /**
     * 글 수정
     * @param seq
     * @param board
     * @param bindingResult
     * @return
     */
    @RequestMapping(value = "/api/board/news/{seq}")
    public ResponseEntity<?> updateBoard(@PathVariable("seq") int seq,
                                        @RequestPart("requestBody") BoardVO board,
                                        @RequestParam("deleteFileSeq") List<Integer> deleteFileSeqs,
                                        MultipartHttpServletRequest request,
                                        BindingResult bindingResult) {

        board.setSeq(seq);
        boardService.updateBoard(board);

        //기존 파일 처리 및 파일 갱신
        boardService.updateBoardFiles( seq, deleteFileSeqs, request.getMultiFileMap());

        return  APIResponseBuilder.success(board).build();
    }


    //TODO: authorize.
    //TODO: comments.
    //TODO: Download attach.

    //TODO: recommend count.
    //TODO: reply.

}

