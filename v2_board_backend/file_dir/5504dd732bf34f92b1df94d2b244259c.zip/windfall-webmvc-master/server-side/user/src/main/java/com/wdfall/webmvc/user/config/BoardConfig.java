package com.wdfall.webmvc.user.config;



import com.wdfall.webmvc.common.domains.board.BoardFileHandler;
import com.wdfall.webmvc.common.domains.board.BoardProperties;
import com.wdfall.webmvc.common.domains.board.BoardService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BoardConfig {




/*
    @Bean
    @ConfigurationProperties(prefix="wdfall.board.free")
    public BoardProperties propertiesForFreeBoard() {
        return new BoardProperties();
    }
*/

    @Bean
    public BoardProperties propertiesForFreeBoard() {
        //TODO: from properties file
        BoardProperties properties = BoardProperties.builder()
                .boardCode("board_free")
                .fileUploadPath("C:\\Temp")
                .filePublicPath("/upload/board/free")
                .build();

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("mainImage")
                        .multiple(1)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("subImage")
                        .multiple(1)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("attaches")
                        .multiple(5)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        return properties;
    }


    @Bean
    public BoardProperties propertiesForNotice() {
        //TODO: from properties file
        BoardProperties properties = BoardProperties.builder()
                .boardCode("notice")
                .fileUploadPath("C:\\Temp")
                .filePublicPath("/upload/board/notice")
                .build();

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("mainImage")
                        .multiple(1)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("subImage")
                        .multiple(1)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("attaches")
                        .multiple(5)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        return properties;
    }


    @Bean
    public BoardProperties propertiesForNewsBoard() {
        //TODO: from properties file
        BoardProperties properties = BoardProperties.builder()
                .boardCode("news")
                .fileUploadPath("C:\\Temp")
                .filePublicPath("/upload/board/news")
                .build();

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("mainImage")
                        .multiple(1)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("subImage")
                        .multiple(1)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        properties.addUploadField(
                BoardProperties.UploadFieldProperty.builder()
                        .fieldName("attaches")
                        .multiple(5)
                        .limitSize(1000000)
                        .acceptableFiles( new String[]{"png","jpg"} )
                        .build()
        );

        return properties;
    }


    @Bean
    public BoardFileHandler boardFileHandler() {
        return new BoardFileHandler();
    }


    @Bean
    public BoardService boardFreeService() throws Exception {
        return new BoardService( propertiesForFreeBoard(), boardFileHandler() );
    }

    @Bean
    public BoardService boardNoticeService() throws Exception {
        return new BoardService( propertiesForNotice(), boardFileHandler() );
    }

    @Bean
    public BoardService boardNewsService() throws Exception {
        return new BoardService( propertiesForNewsBoard(), boardFileHandler() );
    }



}
