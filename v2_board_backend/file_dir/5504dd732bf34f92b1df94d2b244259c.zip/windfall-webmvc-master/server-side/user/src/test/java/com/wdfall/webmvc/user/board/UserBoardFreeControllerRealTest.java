package com.wdfall.webmvc.user.board;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.wdfall.webmvc.common.domains.board.BoardService;
import com.wdfall.webmvc.common.domains.board.BoardVO;


import com.wdfall.webmvc.user.controller.board.BoardFreeController;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {BoardFreeController.class})
@ComponentScan(basePackages = {"com.wdfall.webmvc.common", "com.wdfall.webmvc.user"})
@ActiveProfiles("dev")
public class UserBoardFreeControllerRealTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext ctx;

    @Autowired
    private ObjectMapper objectMapper;


    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx)
                .addFilters(new CharacterEncodingFilter("UTF-8", true))
                .alwaysDo(print())
                .build();
    }


    @Test
    public void listTest() throws Exception {

        // mock request
        final ResultActions actions = mockMvc.perform(
                get("/api/board/free?title=제목&page=1")
                .contentType(MediaType.APPLICATION_JSON).characterEncoding("UTF-8")
        ).andDo(print());

        //then
        actions.andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.response.rows[0].title").value("title222")
                );

    }


    @Test
    public void viewTest() throws Exception {

        // mock request
        final ResultActions actions = mockMvc.perform(
                get("/api/board/free/1")
                .contentType(MediaType.APPLICATION_JSON).characterEncoding("UTF-8")
        ).andDo(print());

        //then
        actions.andExpect(status().isOk())
                .andExpect( content().contentType(MediaType.APPLICATION_JSON) )
                .andExpect( jsonPath("$.response.title").value("제목") );

    }

    @Test
    public void insertTest() throws Exception {

        // mock request
        BoardVO requestVO = BoardVO.builder()
                .title("제목")
                .contents("내용")
                .passwd("1234")
                .author("Hong Jim")
                .build();
        String requestBody = objectMapper.writeValueAsString(requestVO);

        MockMultipartFile mainImage = new MockMultipartFile("mainImage", "my-main-image.jpg", "image/jpeg",
                "this-is-test-binary-data".getBytes());
        MockMultipartFile subImage = new MockMultipartFile("subImage", "my-sub-image.jpg", "image/jpeg",
                "this-is-test-binary-data".getBytes());

        MockMultipartFile fileUrlFile1 = new MockMultipartFile("attaches", "sample-image.png", "image/jpeg",
                "this-is-test-binary-data".getBytes());
        MockMultipartFile fileUrlFile2 = new MockMultipartFile("attaches", "my-image-2.jpg", "image/jpeg",
                "this-is-test-binary-data".getBytes());
        MockMultipartFile fileUrlFile3 = new MockMultipartFile("attaches", "my-image-3.jpg", "image/jpeg",
                "this-is-test-binary-data".getBytes());


        MockMultipartFile json = new MockMultipartFile("requestBody", "jsondata", "application/json"
                ,requestBody.getBytes("UTF8"));


        // Multipart Form data 형태에서의 파라미터
        final ResultActions actions = mockMvc.perform(
                multipart("/api/board/free")
                        .file(json)
                        .file(mainImage)
                        .file(subImage)
                        .file(fileUrlFile1)
                        .file(fileUrlFile2)
                        .file(fileUrlFile3)
                        .contentType("multipart/mixed")
                        .accept(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8")
        ).andDo(print());


        actions .andExpect( status().isOk() )
                .andExpect( content().contentType(MediaType.APPLICATION_JSON) )
                .andExpect( jsonPath("$.response.title").value("제목") );
    }

    @Test
    public void updateTest() throws Exception {

        // mock request
        BoardVO requestVO = BoardVO.builder()
                .title("수정된제목")
                .contents("내용2")
                .author("author22")
                .build();
        String requestBody = objectMapper.writeValueAsString(requestVO);

        MockMultipartFile mainImage = new MockMultipartFile("mainImage", "my-main-image.jpg", "image/jpeg",
                "this-is-test-binary-data".getBytes());
        MockMultipartFile subImage = new MockMultipartFile("subImage", "my-sub-image.jpg", "image/jpeg",
                "this-is-test-binary-data".getBytes());

        MockMultipartFile fileUrlFile1 = new MockMultipartFile("attaches", "sample-image.png", "image/jpeg",
                "this-is-test-binary-data".getBytes());
        MockMultipartFile fileUrlFile2 = new MockMultipartFile("attaches", "my-image-2.jpg", "image/jpeg",
                "this-is-test-binary-data".getBytes());
        MockMultipartFile fileUrlFile3 = new MockMultipartFile("attaches", "my-image-3.jpg", "image/jpeg",
                "this-is-test-binary-data".getBytes());


        MockMultipartFile json = new MockMultipartFile("requestBody", "jsondata", "application/json"
                ,requestBody.getBytes("UTF8"));



        MockMultipartHttpServletRequestBuilder builder = multipart("/api/board/free/1?deleteFileSeq=3&deleteFileSeq=4");
        builder.with(request -> { request.setMethod("PUT"); return request; }); // multipart 가 POST만 제공하므로.
        final ResultActions actions = mockMvc.perform(
                builder
                        .file(json)
                        .file(mainImage)
                        .file(subImage)
                        .file(fileUrlFile1)
                        .file(fileUrlFile2)
                        .file(fileUrlFile3)
                        .contentType("multipart/mixed")
                        .accept(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8")
        ).andDo(print());

        actions .andExpect( status().isOk() )
                .andExpect( content().contentType(MediaType.APPLICATION_JSON) )
                .andExpect( jsonPath("$.response.title").value("수정된제목") );
    }


    @Test
    public void deleteTest() throws Exception {

        // mock request
        final ResultActions actions = mockMvc.perform(
                delete("/api/board/free/53")
                .contentType(MediaType.APPLICATION_JSON)
        ).andDo(print());

        actions.andExpect( status().isOk() );
    }


}