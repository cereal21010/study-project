package com.wdfall.webmvc.user.board;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.wdfall.webmvc.common.domains.board.BoardSearchCondition;
import com.wdfall.webmvc.common.domains.board.BoardService;
import com.wdfall.webmvc.common.domains.board.BoardVO;
import com.wdfall.webmvc.user.controller.board.BoardFreeController;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {BoardFreeController.class})
@ComponentScan(basePackages = {"com.wdfall.webmvc.common", "com.wdfall.webmvc.user"})
@ActiveProfiles("dev")
public class UserBoardFreeControllerMockTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext ctx;

    @MockBean
    private BoardService testService;

    @Autowired
    private ObjectMapper objectMapper;


    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx)
                .addFilters(new CharacterEncodingFilter("UTF-8", true))
                .alwaysDo(print())
                .build();
    }


    @Test
    public void listTest() throws Exception {

        // mock response
        List<BoardVO> list = new ArrayList<>();
        BoardVO testVo = BoardVO.builder().title("title").contents("contents").build();
        list.add(testVo);

        // mock service action
        Mockito.when(
                testService.getBoardList(ArgumentMatchers.any(BoardSearchCondition.class))
        ).thenReturn(list);

        // mock request
        final ResultActions actions = mockMvc.perform(
                get("/api/board/free")
                .contentType(MediaType.APPLICATION_JSON).characterEncoding("UTF-8")
        ).andDo(print());

        //then
        actions.andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.response[0].title").value("title")
                );

    }


    @Test
    public void viewTest() throws Exception {

        // mock response
        BoardVO testVo = BoardVO.builder().title("title").contents("contents").build();

        // mock service action
        Mockito.when(
                testService.getBoard(ArgumentMatchers.any(Integer.class))
        ).thenReturn(testVo);

        // mock request
        final ResultActions actions = mockMvc.perform(
                get("/api/board/1")
                .contentType(MediaType.APPLICATION_JSON).characterEncoding("UTF-8")
        ).andDo(print());

        //then
        actions.andExpect(status().isOk())
                .andExpect( content().contentType(MediaType.APPLICATION_JSON) )
                .andExpect( jsonPath("$.response.title").value("title") );

    }

    @Test
    public void insertTest() throws Exception {

        // mock response
        BoardVO testVo = BoardVO.builder().title("title").contents("contents").build();

        // mock service action
        Mockito.when(
                testService.insertBoard(ArgumentMatchers.any(BoardVO.class))
        ).thenReturn(testVo);


        // mock request
        BoardVO requestVO = BoardVO.builder().title("title").contents("contents").build();
        String content = objectMapper.writeValueAsString(requestVO);
        System.out.println(content);
        final ResultActions actions = mockMvc.perform(
                post("/api/board")
                .content(content)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        ).andDo(print());

        actions .andExpect( status().isOk() )
                .andExpect( content().contentType(MediaType.APPLICATION_JSON) )
                .andExpect( jsonPath("$.response.title").value("title") );
    }

    @Test
    public void updateTest() throws Exception {

        // mock response
        BoardVO testVo = BoardVO.builder().title("title").contents("contents").build();

        // mock service action
        Mockito.when(
                testService.updateBoard(ArgumentMatchers.any(BoardVO.class))
        ).thenReturn(testVo);


        // mock request
        BoardVO requestVO = BoardVO.builder().title("title").contents("contents").build();
        String content = objectMapper.writeValueAsString(requestVO);
        System.out.println(content);
        final ResultActions actions = mockMvc.perform(
                put("/api/board/1")
                .content(content)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        ).andDo(print());

        actions .andExpect( status().isOk() )
                .andExpect( content().contentType(MediaType.APPLICATION_JSON) )
                .andExpect( jsonPath("$.response.title").value("title") );
    }


    @Test
    public void deleteTest() throws Exception {

        // mock request
        final ResultActions actions = mockMvc.perform(
                delete("/api/board/1")
                .contentType(MediaType.APPLICATION_JSON)
        ).andDo(print());

        actions.andExpect( status().isOk() );
    }


}