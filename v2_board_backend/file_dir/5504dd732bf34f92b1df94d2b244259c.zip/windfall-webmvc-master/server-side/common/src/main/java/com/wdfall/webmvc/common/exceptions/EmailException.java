package com.wdfall.webmvc.common.exceptions;

/**
 * 이메일 발송 실패
 */
public class EmailException extends RuntimeException {

    public EmailException(String msg){
        super(msg);
    }
    public EmailException(){
        super();
    }
}
