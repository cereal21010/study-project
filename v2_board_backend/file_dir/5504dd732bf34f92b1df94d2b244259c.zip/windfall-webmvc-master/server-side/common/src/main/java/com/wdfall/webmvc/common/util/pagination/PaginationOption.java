package com.wdfall.webmvc.common.util.pagination;

import lombok.Data;

import javax.servlet.http.HttpServletRequest;

@Data
public class PaginationOption {

    public PaginationOption() {}


    public PaginationOption(HttpServletRequest request) {

        this.pageSize = Integer.valueOf( request.getParameter("pageSize") );
        this.rowSize = Integer.valueOf( request.getParameter("rowSize") );
    }


    /**
     * 표시되는 페이지의 개수
     * 기본값: 10
     */
    private int pageSize = 10;


    /**
     * 한 페이지에 표시되는 데이터 개수
     * 기본값: 10
     */
    private int rowSize = 10;

}
