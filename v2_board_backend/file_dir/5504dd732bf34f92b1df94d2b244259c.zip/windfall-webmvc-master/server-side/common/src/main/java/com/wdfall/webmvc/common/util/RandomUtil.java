package com.wdfall.webmvc.common.util;

import org.apache.commons.lang3.RandomStringUtils;

import java.util.Random;
import java.util.stream.IntStream;

public class RandomUtil {

    /**
     * random 비밀번호
     * @return
     */
    public static String generateRandomPassword() {
        String seed = "ABCDEFGHIJKLNMOPQRSTUVWXYZabcdefghijklnmopqrstuvwxyz0123456789!@#$%^&*()_+";
        int length = 8;
        return RandomStringUtils.random(length, seed);
    }



}
