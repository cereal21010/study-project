package com.wdfall.webmvc.common.util.pagination;

import lombok.Data;

@Data
public class Page {

    public Page(int index) {
        this.index = index;
    }

    /**
     * 페이지 번호
     */
    private int index;

    /**
     * 현재 자신이 선택된 페이지인지 여부
     */
    private boolean isCurrentPage;


    @Override
    public String toString() {
        if( isCurrentPage ) {
            return index+ "-on";
        } else {
            return String.valueOf(index);
        }

    }

}
