package com.wdfall.webmvc.common.token;

import com.wdfall.webmvc.common.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * auth exception
 */
@Slf4j
public class VAuthException extends RuntimeException {

    /**
     * 서버 코드 구분 : 610 - 토큰 없음, 620 - 토큰 만료, 630 - 토큰 무효
     */
    private EnumServerCode codeEnum;

    public VAuthException() {
    }

    public VAuthException(EnumServerCode codeEnum) {
        this.codeEnum = codeEnum;
    }

    public String getJsonMsg() {
        String jsonMsg = "";
        try {
            if( this.codeEnum != null) {
                Map<String, String> map = new HashMap<>();
                map.put("code", this.codeEnum.getCode());
                map.put("msg", this.codeEnum.getMsg());
                jsonMsg = JsonUtils.toJson(map);
            }
        } catch (Exception e) {
            log.error("", e);
            jsonMsg = "";
        }
        return jsonMsg;
    }

    /**
     * 토큰 상태 코드
     */
    public static enum EnumServerCode {
        TOKEN_NOT_EXIST("610", "토큰이 없습니다.")
        , TOKEN_EXPIRED("620", "토큰이 만료되었습니다.")
        , TOKEN_NOT_VALID("630", "토큰이 무효입니다.")
        ;
        private String code;
        private String msg;

        EnumServerCode(String serverCode, String msg) {
            this.code = serverCode;
            this.msg = msg;
        }

        public String getCode() {
            return code;
        }

        public String getMsg() {
            return msg;
        }
    }




}
