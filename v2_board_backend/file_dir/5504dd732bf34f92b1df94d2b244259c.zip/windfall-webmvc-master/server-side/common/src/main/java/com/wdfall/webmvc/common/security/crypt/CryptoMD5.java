package com.wdfall.webmvc.common.security.crypt;

/**
 * Created by IntelliJ IDEA.
 * User: Royalvip
 * Date: 11. 4. 18
 * Time: 오후 12:00
 * MD5 암호화를 실행한다. 단방향이며 복호화 할 수 없다. (패스워드 암호화용으로 추천)
 */
public interface CryptoMD5 {

    public String encrypt(String plain);

}
