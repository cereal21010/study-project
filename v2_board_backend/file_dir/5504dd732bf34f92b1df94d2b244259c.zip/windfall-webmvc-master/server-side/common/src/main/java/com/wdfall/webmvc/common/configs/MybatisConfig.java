package com.wdfall.webmvc.common.configs;


import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Slf4j
@EnableTransactionManagement
@Configuration
@MapperScan(value = {"com.wdfall.webmvc.*"})
public class MybatisConfig {

    @Bean
    public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {

        SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();

        /** Customer Module에서 사용할 경우 mapper 추가로 등록  **/
        Resource[] mappers = null;
        Resource[] commonMappers = new PathMatchingResourcePatternResolver().getResources("classpath:mybatis-mappers/**/*.xml");
        log.error("Loading mybatis-mappers {}", ArrayUtils.toString(commonMappers) );

        boolean existCustomerMappers = new PathMatchingResourcePatternResolver().getResource("classpath:mybatis-mappers-customer").exists();
        if(existCustomerMappers){
            Resource[] customerMappers = new PathMatchingResourcePatternResolver().getResources("classpath:mybatis-mappers-customer/*.xml");
            mappers = ArrayUtils.addAll(
                    commonMappers,
                    customerMappers
            );
        }else{
            mappers = commonMappers;
        }

        sessionFactory.setDataSource(dataSource);
        sessionFactory.setMapperLocations( mappers );
        sessionFactory.setConfigLocation(
                new PathMatchingResourcePatternResolver().getResource("classpath:mybatis-config.xml"));
        return sessionFactory.getObject();
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }


    @Bean
    @ConfigurationProperties(prefix="spring.datasource.hikari")
    public HikariConfig hikariConfig() {
        return new HikariConfig();
    }

    @Bean
    public DataSource dataSource() {
        DataSource dataSource = new HikariDataSource(hikariConfig());
        return dataSource;
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dataSource());
    }


}
