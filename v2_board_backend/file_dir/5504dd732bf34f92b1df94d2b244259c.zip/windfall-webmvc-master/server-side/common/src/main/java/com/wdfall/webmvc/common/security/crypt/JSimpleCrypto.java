package com.wdfall.webmvc.common.security.crypt;

import java.util.Random;

/**
 * 
 * Copyright (c) 2005 FCS Co. Ltd. All right reserved.
 * 			"Innovation + Revolution = Innovative technologies start revolution."
 * 
 * file name: 			JSimpleCrypto.java
 * author: 			KeunHak, Lee (royalvip@innorev.co.kr)
 * creation date: 		2005-11-07
 * enclosing project: 	KWDI
 *
 */
public class JSimpleCrypto implements Crypto{
	
	private char[] o;
	private char[][] e1;
	
	public JSimpleCrypto(CryptoKey key){
		this.o = key.getOriginalKeys();
		this.e1 = key.getSubstitutionKeys();
	}
	
	
	/* (비Javadoc)
	 * @see org.jdf4.core.security.ICryptograph#decrypt(java.lang.String)
	 */
	public String decrypt(String ciphertext) {
		if(ciphertext == null) return null;
		if(ciphertext.length() < 1) return "";
		
		int key = ciphertext.getBytes()[0]-33;
		char[] values = ciphertext.substring(1).toCharArray();
		
		char[] r = decryption(key, values);
		
		return new String(r);
	}
	
	private char[] decryption(int key, char[] ciphertexts){
		char[] r = new char[ciphertexts.length]; 
		
		for (int i = 0; i < ciphertexts.length; i++) {
			int p = indexOf(e1[key], ciphertexts[i]);
			if(p > 0)
				r[i] = o[p];
			else
				r[i] = ciphertexts[i];
		}
		return r;
	}
	
	private char[] encryption(int key, char[] plaintexts){
		char[] r = new char[plaintexts.length]; 
		
		for (int i = 0; i < plaintexts.length; i++) {
			int p = indexOf(o, plaintexts[i]);
			if(p > 0)
				r[i] = e1[key][p];
			else
				r[i] = plaintexts[i];
		}
		return r;
	}
	
	/* (비Javadoc)
	 * @see org.jdf4.core.security.ICryptograph#encrypt(int, java.lang.String)
	 */
	public String encrypt(String plaintext) {
		Random random = new Random(System.currentTimeMillis());
		int key = random.nextInt(93);
		
		return encrypt(key, plaintext);
	}
	
	public String encrypt(int key, String plaintext) {
		if(plaintext == null) return null;
		if(plaintext.length() < 1) return "";

		char[] values = plaintext.toCharArray();
		
		char[] r = encryption(key%e1.length, values);
		
		char[] k = new char[1];
		
		k[0] = (char)(key+33);

		return new String(k) + new String(r);
	}

	
	private int indexOf(char[] chars, char c){
		int r = -1;
		for (int i = 0; i < chars.length; i++) {
			if(chars[i] == c){
				r = i;
				break;
			}
		}
		return r;
	}
	
	public static void main(String[] args){
		JSimpleCrypto sc = new JSimpleCrypto(new JCryptoKey());
		String e = sc.encrypt(args[0]);
		System.out.print(e + " / ");		
		System.out.println(sc.decrypt(e));

	}
}
