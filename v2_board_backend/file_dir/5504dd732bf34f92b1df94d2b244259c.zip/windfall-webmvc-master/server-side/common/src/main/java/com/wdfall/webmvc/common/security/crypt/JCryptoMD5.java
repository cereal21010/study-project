package com.wdfall.webmvc.common.security.crypt;

import java.security.MessageDigest;

/**
 * Created by IntelliJ IDEA.
 * User: Royalvip
 * Date: 11. 4. 18
 * Time: 오전 11:58
 * MD5 암호화를 실행한다. 단방향이며 복호화 할 수 없다. (패스워드 암호화용으로 추천)
 */
public class JCryptoMD5 implements CryptoMD5 {

    public String encrypt(String plain) {
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            return "";
        }

        String eip;
        byte[] bip;
        String temp = "";
        String tst = plain;

        bip = md5.digest(tst.getBytes());
        for (byte aBip : bip) {
            eip = "" + Integer.toHexString((int) aBip & 0x000000ff);
            if (eip.length() < 2) eip = "0" + eip;
            temp = temp + eip;
        }
        return temp;
    }

	public static void main(String[] args){
		JCryptoMD5 sc = new JCryptoMD5();
		String e = sc.encrypt(args[0]);
		System.out.print("original : " + args[0] + "\n");
		System.out.println("encrypted : " + e);
	}

}
