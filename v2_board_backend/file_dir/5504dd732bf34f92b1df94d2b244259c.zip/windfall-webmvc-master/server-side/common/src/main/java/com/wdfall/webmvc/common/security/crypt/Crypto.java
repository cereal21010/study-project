package com.wdfall.webmvc.common.security.crypt;

/**
 * 
 * Copyright (c) 2005 FCS Co. Ltd. All right reserved.
 * 			"Innovation + Revolution = Innovative technologies start revolution."
 * 
 * file name: 			Crypto.java
 * author: 			KeunHak, Lee (royalvip@innorev.co.kr)
 * creation date: 		2005-11-07
 * enclosing project: 	KWDI
 *
 */
public interface Crypto {
	
	public String decrypt(String cipher);
		
	public String encrypt(int key, String plain);
	
	public String encrypt(String plain);
}
