package com.wdfall.webmvc.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.beanutils.BeanUtils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ObjectUtil {

    /**
     * pojo 클래스로 바인딩
     * @param map
     * @param pojo
     * @return
     */
    public static <T extends  Object> T toObject(Map map, Class<T> pojo) {

        ObjectMapper mapper = new ObjectMapper();

        Map<String, Object> simpleMap = createParamMap(map);

        return mapper.convertValue(simpleMap, pojo);
    }

    /**
     * 리퀘스트 파라미터 생성
     * @param requestMap
     * @return
     */
    public static Map<String, Object> createParamMap(Map requestMap ) {

        Map<String, Object> parameterMap = new HashMap<>();
        Iterator<String> iters = requestMap.keySet().iterator();

        while(iters.hasNext()){
            String key = iters.next();
            String[] parameters = (String[])requestMap.get(key);

            // Parameter가 배열일 경우
            if(parameters.length > 1){
                parameterMap.put(key, parameters);
                // Parameter가 배열이 아닌 경우
            }else{
                parameterMap.put(key, parameters[0]);
            }
        }

        return parameterMap;
    }
}
