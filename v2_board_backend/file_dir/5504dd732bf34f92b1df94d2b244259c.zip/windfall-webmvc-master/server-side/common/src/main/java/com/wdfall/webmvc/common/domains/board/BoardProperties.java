package com.wdfall.webmvc.common.domains.board;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;


@Data
@Builder(toBuilder = true)
public class BoardProperties {
    String boardCode;
    boolean enableCategory;
    String fileUploadPath;
    String filePublicPath;


    public UploadFieldProperty getDefineUploadField(String fieldName){
        for (UploadFieldProperty uploadField : uploadFieldProperties) {
            if(uploadField.fieldName.equals(fieldName)){
                return uploadField;
            }
        }
        return null;
    }

    @Builder.Default
    List<UploadFieldProperty> uploadFieldProperties = new ArrayList<>();

    public void addUploadField(UploadFieldProperty uploadFieldProperty) {
        uploadFieldProperties.add(uploadFieldProperty);
    }


    @AllArgsConstructor
    @Builder(toBuilder = true)
    public static class UploadFieldProperty {

        @Getter
        String fieldName;

        @Getter
        long limitSize; // 0이라면 제한 없음

        @Getter
        boolean enableUri; // public uri로 접근 가능한 리소스인가

        @Getter
        @Builder.Default
        int multiple = 1;

        @Getter
        @Builder.Default
        String[] acceptableFiles = {"png","jpg"};   // acceptable 이 정의되었다면, denied는 무시

        @Getter
        @Builder.Default
        String[] deniedFiles = {};

        public boolean enableMultiple(){
            return multiple > 1;
        }
    }
}
