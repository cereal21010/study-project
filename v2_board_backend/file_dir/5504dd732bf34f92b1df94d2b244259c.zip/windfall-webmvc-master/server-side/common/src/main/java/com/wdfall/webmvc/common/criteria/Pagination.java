package com.wdfall.webmvc.common.criteria;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString(callSuper = true)
public class Pagination {

    /**
     * 총 데이터 수
     */
    @Getter@Setter
    private int totalCount;

    /**
     * 현재 페이지
     */
    @Getter@Setter
    private int page = 1;

    /**
     * 페이지별 데이터 수
     */
    @Getter@Setter
    private int perPage;


    public Pagination() {
        this.perPage = 20;
    }

    /**
     * 생성자 (페이지별 데이터 개수: $perPageNum$)
     */
    public Pagination(int perPage) {
        this();
        this.perPage = perPage;
    }

    public int getStartInPage(){
        if(page > 1) {
            return perPage * (page -1);
        } else {
            return 0;
        }
    }


}
