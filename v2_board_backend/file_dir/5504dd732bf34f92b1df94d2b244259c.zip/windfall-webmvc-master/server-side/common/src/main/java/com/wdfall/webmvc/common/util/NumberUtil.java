package com.wdfall.webmvc.common.util;


public class NumberUtil {

    private NumberUtil(){}

}
