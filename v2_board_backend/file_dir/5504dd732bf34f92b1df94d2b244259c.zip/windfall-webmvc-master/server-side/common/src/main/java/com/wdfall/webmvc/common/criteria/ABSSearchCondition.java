package com.wdfall.webmvc.common.criteria;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString(callSuper = true)
public abstract class ABSSearchCondition extends Pagination{

    @Getter@Setter
    private String orderBy;

    @Getter@Setter
    private String orderDir;

}
