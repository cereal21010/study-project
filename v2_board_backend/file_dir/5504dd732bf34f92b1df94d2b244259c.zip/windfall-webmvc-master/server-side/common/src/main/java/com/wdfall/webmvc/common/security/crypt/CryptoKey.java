package com.wdfall.webmvc.common.security.crypt;

/**
 * 
 * Copyright (c) 2005 FCS Co. Ltd. All right reserved.
 * 			"Innovation + Revolution = Innovative technologies start revolution."
 * 
 * file name: 			CryptoKey.java
 * author: 			KeunHak, Lee (royalvip@innorev.co.kr)
 * creation date: 		2005-11-08
 * enclosing project: 	KWDI
 *
 */
public interface CryptoKey {
	
	public char[] getOriginalKeys();
	
	public char[][] getSubstitutionKeys();
	
}
