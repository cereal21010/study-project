package com.wdfall.webmvc.common.domains.board;


import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.google.common.collect.ArrayListMultimap;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MultiMap;
import org.apache.commons.collections4.map.MultiValueMap;

import java.sql.Timestamp;
import java.util.*;


@NoArgsConstructor
@AllArgsConstructor
@ToString
@SuperBuilder
public class BoardVO {

    @Getter
    @Setter
    private int seq;

    @Getter@Setter
    private String title;

    @Getter@Setter
    private String contents;

    @Getter@Setter
    private int viewCount;

    @JsonIgnore
    @Getter@Setter
    private String passwd;

    @Getter@Setter
    private String author;

    @Getter@Setter
    private Timestamp registerTime;

    @Getter@Setter
    private Timestamp updateTime;


    @JsonIgnore
    private Map<String, BoardFileVO> singleFileMap;
    @JsonIgnore
    private MultiMap<String, BoardFileVO> multiFileMap;


    @JsonAnyGetter
    @JsonProperty("files")
    public Map<String, Object> getFiles(){

        Map<String, Object> attachedFiles = new HashMap<>();

        if( singleFileMap!= null ){
            for( String key : singleFileMap.keySet() ){
                attachedFiles.put(key, singleFileMap.get(key) );
            }
        }

        if( multiFileMap != null ){
            for( String key : multiFileMap.keySet() ){
                attachedFiles.put(key, multiFileMap.get(key) );
            }
        }

        return attachedFiles;
    }


    /**
     * 단일 파일 추가
     * @param fieldName
     * @param boardFile
     */
    public void putFile( String fieldName, BoardFileVO boardFile ){
        if( singleFileMap == null){
            singleFileMap = new HashMap<>();
        }
        singleFileMap.put(fieldName, boardFile);
    }

    /**
     * 멀티 파일 추가
     * @param fieldName
     * @param targetFiles
     */
    public void putFiles(String fieldName, List<BoardFileVO> targetFiles) {
        if( multiFileMap == null){
            multiFileMap = new MultiValueMap<>();
        }
        for(BoardFileVO boardFile : targetFiles){
            multiFileMap.put(fieldName, boardFile);
        }
    }
}
