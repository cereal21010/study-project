package com.wdfall.webmvc.common.domains.board;

import com.wdfall.webmvc.common.criteria.ABSSearchCondition;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString(callSuper = true)
public class BoardSearchCondition extends ABSSearchCondition {

    @Getter @Setter
    private String title;

    @Getter @Setter
    private String contents;

    @Getter @Setter
    private String author;

    public BoardSearchCondition(){

        //TODO: 이게 여기 있는게 맞나?
        setPerPage(2);
        setOrderBy("seq");
        setOrderDir("desc");
    }

}
