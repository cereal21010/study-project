package com.wdfall.webmvc.common.util;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeUtil {

    private DateTimeUtil(){}


    /**
     *
     * Usage : DateTimeUtil.now("YYYYMMddHHmmss")
     * @param format
     * @return
     */
    public static String now(String format) {
        Date date = new Date( System.currentTimeMillis() );
        DateFormat output = new SimpleDateFormat(format);
        return output.format(date);
    }

}
