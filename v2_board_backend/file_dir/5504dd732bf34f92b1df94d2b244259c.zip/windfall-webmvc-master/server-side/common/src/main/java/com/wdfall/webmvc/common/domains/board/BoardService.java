package com.wdfall.webmvc.common.domains.board;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 게시판 서비스
 * 주의: Service annotation을 사용하지 않음. BoardConfig에서 직접 Bean을 생성하여 ioc에 주입.
 */
@Slf4j
public class BoardService {

    @Autowired
    BoardMapper mapper;

    @Getter
    BoardProperties boardProperties;

    @Getter
    BoardFileHandler fileHandler;

    public BoardService(BoardProperties boardProperties, BoardFileHandler fileHandler) {
        this.boardProperties = boardProperties;
        this.fileHandler = fileHandler;
    }

    public List<BoardVO> getBoardList(BoardSearchCondition search) {
        int totalCount = mapper.getBoardCount(boardProperties.boardCode, search);
        search.setTotalCount( totalCount );

        return mapper.getBoardList(boardProperties.boardCode, search);
    }

    public void deleteBoard(int seq) {
        deleteFiles(seq);
        mapper.deleteBoard(boardProperties.boardCode, seq);
    }

    public BoardVO getBoard(int seq) {
        BoardVO board = mapper.findBoardBySeq(boardProperties.boardCode, seq);

        List<BoardFileVO> boardFiles = mapper.getBoardFiles(boardProperties.boardCode, BoardFileVO.Search.builder().boardSeq(seq).build() );

        _injectFilesToBoardVO(board, boardFiles);

        return board;
    }

    private void _injectFilesToBoardVO(BoardVO board, List<BoardFileVO> boardFiles){
        List<BoardProperties.UploadFieldProperty> uploadFields = getUploadFieldProperties();
        for (BoardProperties.UploadFieldProperty uploadField : uploadFields) {
            String fieldName = uploadField.getFieldName();

            List<BoardFileVO> targetFiles = boardFiles.stream()
                    .filter( v -> fieldName.equals(v.getFieldName()) )
                    .collect(Collectors.toList());


            if(uploadField.enableMultiple()){
                board.putFiles( fieldName, targetFiles );
            }else{
                if(targetFiles.size() >= 1){
                    board.putFile( fieldName, targetFiles.get(0) );
                }
            }
        }
    }

    public BoardVO insertBoard(BoardVO board) {
        mapper.insertBoard(boardProperties.boardCode, board);
        return board;
    }

    public BoardVO updateBoard(BoardVO board) {
        //기존 데이타를 가져와서 비교하여 속성값 병합.
        BoardVO targetBoard = mapper.findBoardBySeq(boardProperties.boardCode, board.getSeq() );
        _overrideNotEmptyValues( board, targetBoard );
        mapper.updateBoard(boardProperties.boardCode, targetBoard);
        return targetBoard;
    }

    private void _overrideNotEmptyValues(BoardVO from, BoardVO to){
        final String[] ignoreFields = {"seq"};

        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(from.getClass());
            for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {

                if (descriptor.getWriteMethod() != null) {
                    Object fromValue = descriptor.getReadMethod().invoke(from);

                    if (fromValue != null && !Arrays.stream(ignoreFields).anyMatch(descriptor.getName()::equals) ) {
                        if (fromValue instanceof Number) {
                            if( ((Number) fromValue).intValue() <= 0 ){
                                continue;
                            }
                        }

                        descriptor.getWriteMethod().invoke(to, fromValue);
                    }
                }

            }
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new RuntimeException(e);
        }
    }



    public void storeFiles(int boardSeq, Map<String, List<MultipartFile>> multipartFileMap) {

        List<BoardProperties.UploadFieldProperty> uploadFields = getUploadFieldProperties();
        for (BoardProperties.UploadFieldProperty uploadField : uploadFields) {

            String fieldName = uploadField.getFieldName();
            List<MultipartFile> multipartFiles =  multipartFileMap.get(fieldName);
            _storeFiles(boardSeq, uploadField, multipartFiles);

        }
    }

    private void _storeFiles(int boardSeq, BoardProperties.UploadFieldProperty uploadField , List<MultipartFile> multipartFiles) {

        String fieldName = uploadField.getFieldName();

        List<BoardFileVO> boardFiles = fileHandler.saveAsBoardFiles( boardSeq , boardProperties, fieldName, multipartFiles );
        for ( BoardFileVO file : boardFiles) {
            mapper.insertBoardFile(boardProperties.boardCode , file );
        }
    }

    public void deleteFiles(int boardSeq) {
        List<BoardFileVO> boardFiles = mapper.getBoardFiles(boardProperties.boardCode, BoardFileVO.Search.builder().boardSeq(boardSeq).build());
        _deleteFiles( boardFiles );
    }

    private void _deleteFiles(List<BoardFileVO> boardFiles ){
        if( boardFiles.size() == 0 ){
            return;
        }

        //Delete from Disk
        fileHandler.deleteBoardFiles(boardFiles);

        //Delete from DB
        List<Integer> boardFileSeqs = boardFiles.stream()
                .map( f-> f.getSeq())
                .collect(Collectors.toList());
        mapper.deleteBoardFiles(boardProperties.boardCode, boardFileSeqs);
    }


    public List<BoardProperties.UploadFieldProperty> getUploadFieldProperties(){
        return getBoardProperties().getUploadFieldProperties();
    }

    public void updateBoardFiles(int boardSeq, List<Integer> deleteFileSeqs, Map<String, List<MultipartFile>> multipartFileMap) {

        List<BoardProperties.UploadFieldProperty> uploadFields = getUploadFieldProperties();
        for (BoardProperties.UploadFieldProperty uploadField : uploadFields) {

            String fieldName = uploadField.getFieldName();

            if( uploadField.multiple == 1 ){
                _updateSingleFileField(boardSeq, uploadField, multipartFileMap.get(fieldName));
            }else{
                _updateMultipleFileField(boardSeq, deleteFileSeqs, uploadField, multipartFileMap.get(fieldName));
            }
        }
    }

    private void _updateSingleFileField(int boardSeq, BoardProperties.UploadFieldProperty uploadField, List<MultipartFile> multipartFiles){
        //Replace single file.
        List<BoardFileVO> oldFiles = mapper.getBoardFiles( boardProperties.boardCode,
                BoardFileVO.Search.builder().boardSeq(boardSeq).fieldName( uploadField.getFieldName() ).build()
        );
        _deleteFiles(oldFiles);

        _storeFiles(boardSeq, uploadField, multipartFiles );

    }
    private void _updateMultipleFileField(int boardSeq, List<Integer> deleteFileSeqs, BoardProperties.UploadFieldProperty uploadField, List<MultipartFile> multipartFiles){

        List<BoardFileVO> deleteFiles = mapper.getBoardFiles( boardProperties.boardCode,
                BoardFileVO.Search.builder()
                        .boardSeq(boardSeq)
                        .seqs( deleteFileSeqs )
                        .build()
        );

        _deleteFiles(deleteFiles);

        _storeFiles(boardSeq, uploadField, multipartFiles );
    }

    public void increaseViewCount(int seq) {
        mapper.increaseViewCount(boardProperties.boardCode, seq);
    }
}

