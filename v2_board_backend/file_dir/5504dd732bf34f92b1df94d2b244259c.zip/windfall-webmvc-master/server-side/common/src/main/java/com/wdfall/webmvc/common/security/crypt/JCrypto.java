package com.wdfall.webmvc.common.security.crypt;

import java.util.Random;

/**
 * 
 * Copyright (c) 2005 FCS Co. Ltd. All right reserved.
 * 			"Innovation + Revolution = Innovative technologies start revolution."
 * 
 * file name: 			JCrypto.java
 * author: 			KeunHak, Lee (royalvip@innorev.co.kr)
 * creation date: 		2005-11-03
 * enclosing project: 	KWDI
 *
 */
public class JCrypto implements Crypto{
	
	private char[] o;
	private char[][] e1;
	
	public JCrypto(CryptoKey key){
		this.o = key.getOriginalKeys();
		this.e1 = key.getSubstitutionKeys();
	}
	
	
//	private final char[] o1 = {'!', '"', '#', '$', '%', '&', '\"", '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~'};
//	
//	private final char[][] e11= {
//		{
//			'A', 'K', 'U', 'e', 'o', 'y', '8', '^', '{', '<', 
//			'B', 'L', 'V', 'f', 'p', 'z', '9', '&', '}', '>', 
//			'C', 'M', 'W', 'g', 'q', '`', '0', '*', '|', '?', 
//			'D', ' ', 'X', 'h', 'r', '1', '-', '(', ';', 'E', 
//			'O', 'Y', 'i', 's', '2', '=', ')', '\"", 'F', 'P', 
//			'Z', 'j', 't', '3', '~', '_', ':', 'G', 'Q', 'a', 
//			'k', 'u', '4', '@', '+', '\"', 'H', 'R', 'b', 'l', 
//			'v', '5', '#', '[', ',', 'I', 'S', 'c', 'm', 'w', 
//			'6', '$', ']', '.', 'N', 'T', 'd', 'n', 'x', '7', 
//			'%', '\\', '/', 'J'
//		}, {
//			'O', 'Y', 'i', 's', '2', '=', ')', '\"", 'F', 'P', 
//			'Z', 'j', 't', '3', '~', '_', ':', 'G', 'Q', 'a', 
//			'C', 'M', 'W', 'g', 'q', '`', '0', '*', '|', '?', 
//			'D', ' ', 'X', 'h', 'r', '1', '-', '(', ';', 'E', 
//			'A', 'K', 'U', 'e', 'o', 'y', '8', '^', '{', '<', 
//			'6', '$', ']', '.', 'N', 'I', 'S', 'c', 'm', 'w', 
//			'%', '\\', '/', 'J', 'T', 'd', 'n', 'x', '7', 
//			'k', 'u', '4', '@', '+', '\"', 'H', 'R', 'b', 'l', 
//			'B', 'L', 'V', 'f', 'p', 'z', '9', '&', '}', '>', 
//			'v', '5', '#', '[', ','
//		}, {
//			'<', '>', '?', 'E', 'P', 'a', 'l', 'w', '7', '^', 
//			'&', '*', '(', '\"", 'G', 'R', 'c', 'n', 'y', 'z', 
//			'`', '1', '=', '_', '\"', 'I', 'T', 'e', 'f', 'g', 
//			'h', 's', '3', ' ', '[', '.', 'K', 'L', 'M', 'N', 
//			'Y', 'j', 'u', '5', '$', '\\', '{', '}', '|', ';', 
//			'F', 'Q', 'b', 'm', 'x', '8', '9', '0', '-', ')', 
//			':', 'H', 'S', 'd', 'o', 'p', 'q', 'r', '2', '~',
//			'+', ',', 'J', 'U', 'V', 'W', 'X', 'i', 't', '4',
//			'#', ']', '/', 'A', 'B', 'C', 'D', 'O', 'Z', 'k',
//			'v', '6', '%', '@'
//		}, {
//			'`', '1', '=', '_', '\"', 'I', 'T', 'e', 'f', 'g', 
//			'Y', 'j', 'u', '5', '$', '\\', '{', '}', '|', ';', 
//			':', 'H', 'S', 'd', 'o', 'p', 'q', 'r', '2', '~',
//			'v', '6', '%', 'F', ' ', 'b', 'm', 'x', '8', '9', 
//			'+', ',', 'J', 'U', 'V', 'W', 'X', 'i', 't', '4',
//			'h', 's', '3', '@', '[', '.', 'K', 'L', 'M', 'N', 
//			'<', '>', '?', 'E', 'P', 'a', 'l', 'w', '7', '^', 
//			'&', '*', '(', '\"", 'G', 'R', 'c', 'n', 'y', 'z', 
//			'#', ']', '/', 'A', 'B', 'C', 'D', 'O', 'Z', 'k',
//			'0', '-', ')', 'Q'
//		} , {
//			'+', ',', 'J', 'U', 'V', 'W', 'X', 'i', 't', '4',
//			'v', '6', '%', 'F', ' ', 'b', 'm', 'x', '8', '9', 
//			'h', 's', '3', '@', '[', '.', 'K', 'L', 'M', 'N', 
//			'`', '1', '=', '_', '\"', 'I', 'T', 'e', 'f', 'g', 
//			'<', '>', '?', 'E', 'P', 'a', 'l', 'w', '7', '^', 
//			'Y', 'j', 'u', '5', '$', '\\', '{', '}', '|', ';', 
//			':', 'H', 'S', 'd', 'o', 'p', 'q', 'r', '2', '~',
//			'&', '*', '(', '\"", 'G', 'R', 'c', 'n', 'y', 'z', 
//			'#', ']', '/', 'A', 'B', 'C', 'D', 'O', 'Z', 'k',
//			'0', '-', ')', 'Q'
//		} , {
//			'&', '*', '(', '\"", 'G', 'R', 'c', 'n', 'y', 'z', 
//			'+', ',', 'J', 'U', 'V', 'W', 'X', 'i', 't', '4',
//			'v', '6', '%', 'F', ' ', 'b', 'm', 'x', '8', '9', 
//			'<', '>', '?', 'E', 'P', 'a', 'l', 'w', '7', '^', 
//			'`', '1', '=', '_', '\"', 'I', 'T', 'e', 'f', 'g', 
//			'Y', 'j', 'u', '5', '$', '\\', '{', '}', '|', ';', 
//			'#', ']', '/', 'A', 'B', 'C', 'D', 'O', 'Z', 'k',
//			':', 'H', 'S', 'd', 'o', 'p', 'q', 'r', '2', '~',
//			'0', '-', ')', 'Q', '[', '.', 'K', 'L', 'M', 'N', 
//			'h', 's', '3', '@'
//		}
//	};
	/**
	 * 
	 */
	public JCrypto() {
		super();
		CryptoKey key = new JCryptoKey();
		this.o = key.getOriginalKeys();
		this.e1 = key.getSubstitutionKeys();
	}
	
	public String decrypt(String ciphertext){
		int key = Integer.parseInt(ciphertext.substring(1, ciphertext.indexOf("}")));
		ciphertext = ciphertext.substring(ciphertext.indexOf("}")+1);
		
		char[] chars = ciphertext.toCharArray();
		int e1l = e1.length;
		int _e = key % e1l;	//key=3, _e=3%3=0			| key=10,	_e=10%3=1
		
		for (int i = 1-1; i >= 0; i--) {
			int k = (_e + i) % e1l;	//e[0]=0, e[1]=1, e[2]=2	| e[0]=1, e[1]=2, e[2]=0
			chars = decryption(k, chars);	//1~3차 복호화
		}
		
		return new String(chars);
	}
	
	private char[] decryption(int key, char[] ciphertexts){
		char[] r = new char[ciphertexts.length]; 
		
		for (int i = 0; i < ciphertexts.length; i++) {
			int p = indexOf(e1[key], ciphertexts[i]);
			if(p > 0)
				r[i] = o[p];
			else
				r[i] = ciphertexts[i];
		}
		return r;
	}
	
	
	public String encrypt(String plaintext){
		Random random = new Random(System.currentTimeMillis());
		int key = random.nextInt(10000);
		
		return encrypt(key, plaintext);
	}
	
	public String encrypt(int key, String plaintext){
		char[] chars = plaintext.toCharArray();
		int e1l = e1.length;
		int _e = key % e1l;	//key=3, _e=3%3=0			| key=10,	_e=10%3=1
		
		for (int i = 0; i < 1; i++) {
			int k = (_e + i) % e1l;	//e[0]=0, e[1]=1, e[2]=2	| e[0]=1, e[1]=2, e[2]=0
			chars = encryption(k, chars);	//1~3차 암호화
		}
		
		return "{" + key + "}" + new String(chars);
	}

	
	private char[] encryption(int key, char[] plaintexts){
		char[] r = new char[plaintexts.length]; 
		
		for (int i = 0; i < plaintexts.length; i++) {
			int p = indexOf(o, plaintexts[i]);
			if(p > 0)
				r[i] = e1[key][p];
			else
				r[i] = plaintexts[i];
		}
		return r;
	}
	
	private int indexOf(char[] chars, char c){
		int r = -1;
		for (int i = 0; i < chars.length; i++) {
			if(chars[i] == c){
				r = i;
				break;
			}
		}
		return r;
	}
	
	public int createKey(String ssn){
		int key = 0;
		if(ssn != null && !ssn.equals("") && ssn.length() == 13)
		{
			// 키값 계산...
			key = Integer.parseInt(ssn.substring(0,1)) + Integer.parseInt(ssn.substring(2,3)) + Integer.parseInt(ssn.substring(4,5)) + Integer.parseInt(ssn.substring(6,7)) + Integer.parseInt(ssn.substring(8,9)) + Integer.parseInt(ssn.substring(10,11)) + Integer.parseInt(ssn.substring(12,13)) ;
			String temp = ssn.substring(8,9) + ssn.substring(10,11);
			key *= Integer.parseInt(temp);
			key -= 99;
			key *= 1008;
		}
		return key;
	}
	
	public static void main(String[] args) {
		JCrypto sc = new JCrypto(new JCryptoKey());
		String e = sc.encrypt(args[0]);
		System.out.print(e + " / ");
		System.out.println(sc.decrypt(e));
	}
}
