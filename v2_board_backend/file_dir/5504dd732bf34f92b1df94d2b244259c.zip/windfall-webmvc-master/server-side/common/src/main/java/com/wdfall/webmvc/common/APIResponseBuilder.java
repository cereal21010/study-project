package com.wdfall.webmvc.common;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;


/***
 * Usage :
 *
 * APIResponseBuilder responseBuilder = APIResponseBuilder.success().setData( resultVo );
 * ResponseEntity<Map<String, Object>> responseEntity = responseBuilder.build();
 *
 * APIResponseBuilder responseBuilder = APIResponseBuilder.success().putValue( "seq", 1 ).putValue( "name", "SangYoo" );
 * ResponseEntity<Map<String, Object>> responseEntity = responseBuilder.build();
 *
 * APIResponseBuilder.fail(APIResponseBuilder.ErrorCode.INVALID_INPUT_PARAM, "Seq must be not null.");
 * ResponseEntity<Map<String, Object>> responseEntity = responseBuilder.build();
 *
 */
public class APIResponseBuilder {


    ErrorCode errorCode;
    String message;

    Map<String, Object> responseBodyMap = null;
    Object responseBodyObject = null;


    public APIResponseBuilder(){
    }

    public ResponseEntity<Map<String, Object>> build(){
        Object response = null;
        if( responseBodyObject != null ){
            response = responseBodyObject;
        }else if(responseBodyMap != null ){
            response = responseBodyMap;
        }

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("success",  errorCode == null ? "true": "false" );
        responseBody.put("response", response == null ? "": response);
        responseBody.put("errorCode", errorCode == null ? "": errorCode);
        responseBody.put("message", message == null ? "": message);
        return new ResponseEntity<>(responseBody, HttpStatus.OK);
    }

    public static APIResponseBuilder successWithMessage(Object data, String msg) {
        APIResponseBuilder instance = new APIResponseBuilder();
        instance.setData(data);
        instance.message = msg;
        return instance;
    }
    public static APIResponseBuilder success(Object data) {
        return successWithMessage(data, null);
    }


    public static APIResponseBuilder success() {
        return successWithMessage(null);
    }
    public static APIResponseBuilder successWithMessage(String msg) {
        APIResponseBuilder instance = new APIResponseBuilder();
        instance.message = msg;
        return instance;
    }

    /**
     * http 프로토콜은 성공으로 리턴됨을 주의.
     * @param errorCode
     * @param message
     * @return
     */
    public static APIResponseBuilder fail(ErrorCode errorCode, String message) {
        APIResponseBuilder instance = new APIResponseBuilder();
        instance.errorCode = errorCode;
        instance.message = message;
        return instance;
    }

    /**
     *
     * @param data 객체형태의 파라미터
     * @return
     */
    public APIResponseBuilder setData(Object data ){
        if( responseBodyMap != null ){
            throw new RuntimeException("Already value putted.");
        }
        responseBodyObject = data;
        return this;
    }

    /**
     * 에러코드 세팅. 성공인 경우에도 사용할 수 있음.
     * @param errorCode
     * @return
     */
    public APIResponseBuilder setErrorCode( ErrorCode errorCode ){
        this.errorCode = errorCode;
        return this;
    }

    /**
     *
     * @param key 속성 키
     * @param val 속성 값
     * @return
     */
    public APIResponseBuilder putValue(String key, Object val) {
        if( responseBodyObject != null ){
            throw new RuntimeException("Already data putted.");
        }
        if(responseBodyMap == null){
            responseBodyMap = new HashMap<>();
        }
        responseBodyMap.put(key, val);
        return this;
    }



    /**
     * 에러 코드 enum
     * @author ohseachun
     *
     */
    public static enum ErrorCode {

        /**
         * 토큰없음 비로그인
         */
        NOT_LOGIN,

        /**
         * 권한 에러. 권한이 없는 메뉴 접근.
         */
        ERR_AUTH,

        CANNOT_FOUND_EMAIL, //로그인. 이메일 없음

        INVALID_PASSWORD,   //로그인. 패스워드 틀림

        LOCKED_BY_LOGIN_FAIL_COUNT, ////로그인. 로그인실패 횟수 초과

        CANNOT_ACTIVITY_STATUS, // 활동할수 없는 상태

        /**
         * 입력값 에러
         */
        INVALID_INPUT_PARAM,


        /**
         * 데이터 중복
         */
        DATA_DUPLICATED,
        /**
         * 데이터 없음
         */
        DATA_NOT_FOUND,

        /**
         * 데이터 이미 존재함.
         */
        DATA_ALREADY_EXISTS,

        /**
         * 에러는 아니나 작업에는 실패.
         */
        WORK_FAIL,

        /**
         * 인증 실패. OTP 인증 실패.
         */
        CERTIFICATION_FAIL,

        /**
         *
         */
        SERVER_ERROR,

        /**
         * 마케팅 수신 동의 여부
         */
        MARKETING_NOT_AGREE,

        /**
         * 이메일 수신 동의 여부
         */
        EMAIL_NOT_AGREE,

    }
}
