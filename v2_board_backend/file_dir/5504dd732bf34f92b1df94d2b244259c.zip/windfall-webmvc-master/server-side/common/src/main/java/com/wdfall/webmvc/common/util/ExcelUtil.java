package com.wdfall.webmvc.common.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

import java.util.ArrayList;
import java.util.List;

public class ExcelUtil {

    private ExcelUtil(){}

    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ColumnDefine<T> {
        String title;
        int columnWidth;
        String columnName;

        DataGetter<T> getter;
    }

    @Data
    public static class DataProvider <T>{

        List<ColumnDefine<T>> columns = new ArrayList<>();
        List<T> source;

        public DataProvider(List<T> source){
            this.source = source;
        }
        public int getColumnCount(){
            return columns.size();
        }
        public int getRowCount(){
            return source.size();
        }
        public T get(int i){
            return source.get(i);
        }

        public DataGetter<T> getGetter( int columnIndex ){
            return columns.get(columnIndex).getGetter();
        }

        public String getTitle(int columnIndex){
            return columns.get(columnIndex).getTitle();
        }

        public DataProvider<T> addColumn(String colName, int width, DataGetter<T> dataGetter) {
            ColumnDefine<T> columnsDifine = ColumnDefine.<T>builder()
                    .title(colName)
                    .columnWidth(width)
                    .getter(dataGetter).build();
            this.columns.add(columnsDifine);
            return this;
        }
    }

    @FunctionalInterface
    public interface DataGetter <T>{
        String getValue(T t);
    }


    public static <T>HSSFWorkbook parseListToExcelFile(DataProvider<T> dataProvider) throws Exception{
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet();

        //헤더스타일
        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setAlignment(CellStyle.ALIGN_CENTER); //가운데 정렬
        headerStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER); //높이 가운데 정렬
        //배경색
        headerStyle.setFillForegroundColor(IndexedColors.PALE_BLUE.getIndex());
        headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
        //테두리 선 (우,좌,위,아래)
        headerStyle.setBorderRight(HSSFCellStyle.BORDER_THICK);
        headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THICK);
        headerStyle.setBorderTop(HSSFCellStyle.BORDER_THICK);
        headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THICK);
        //폰트 설정
        Font RedBold14 = workbook.createFont();
        RedBold14.setFontHeight((short)(16*12)); //사이즈
        RedBold14.setBoldweight(Font.BOLDWEIGHT_BOLD); //볼드 (굵게)
        headerStyle.setFont(RedBold14);

        //기본컬럼 스타일
        CellStyle defaultCellStyle = workbook.createCellStyle();
        defaultCellStyle.setAlignment(CellStyle.ALIGN_LEFT); //왼쪽 정렬
        defaultCellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER); //높이 가운데 정렬
        //테두리 선 (우,좌,위,아래)
        defaultCellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
        defaultCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        defaultCellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        defaultCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);

        //헤더
        HSSFRow headerRow = sheet.createRow(0); //엑셀 행 생성
        headerRow.setHeight((short)500); //행높이
        for( int i=0 ; i < dataProvider.getColumnCount()  ; i++ ){
            sheet.setColumnWidth(i,dataProvider.getColumns().get(i).getColumnWidth());
            HSSFCell cell = headerRow.createCell(i);
            cell.setCellStyle(headerStyle);
            cell.setCellValue( dataProvider.getTitle(i) );
        }

        //바디
        for( int r=0 ; r < dataProvider.getRowCount() ; r++ ){
            HSSFRow row = sheet.createRow( r+1 ); //엑셀 행 생성
            for( int i=0 ; i < dataProvider.getColumnCount() ; i++ ){
                HSSFCell cell = row.createCell(i);
                cell.setCellStyle(defaultCellStyle);
                cell.setCellValue( dataProvider.getGetter(i).getValue(dataProvider.get(r)) );
            }
        }

        return workbook;
    }



}
