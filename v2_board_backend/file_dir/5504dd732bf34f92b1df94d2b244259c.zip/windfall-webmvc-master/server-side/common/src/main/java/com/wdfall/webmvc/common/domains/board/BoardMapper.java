package com.wdfall.webmvc.common.domains.board;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 게시판 Mapper
 */
@Mapper
@Repository
public interface BoardMapper {

    int getBoardCount(@Param("boardCode") String boardCode, @Param("search") BoardSearchCondition search);

    List<BoardVO> getBoardList(@Param("boardCode") String boardCode, @Param("search") BoardSearchCondition search);

    BoardVO findBoardBySeq(@Param("boardCode") String boardCode, @Param("seq") int seq);

    void insertBoard(@Param("boardCode") String boardCode, @Param("board") BoardVO board);

    void deleteBoard(@Param("boardCode") String boardCode, @Param("seq") int seq);

    void updateBoard(@Param("boardCode") String boardCode, @Param("board") BoardVO board);

    void insertBoardFile(@Param("boardCode") String boardCode, @Param("boardFile") BoardFileVO boardFile);

    List<BoardFileVO> getBoardFiles(@Param("boardCode")String boardCode,@Param("search") BoardFileVO.Search search);

    int deleteBoardFiles(@Param("boardCode")String boardCode, @Param("seqs")List<Integer> seqs);

    void increaseViewCount(@Param("boardCode") String boardCode, @Param("seq") int seq);
}

