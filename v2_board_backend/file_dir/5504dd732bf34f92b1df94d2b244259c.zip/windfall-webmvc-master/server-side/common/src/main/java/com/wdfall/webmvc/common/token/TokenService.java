package com.wdfall.webmvc.common.token;

import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Map;

@Service
@Slf4j
@Component
public class TokenService {

    public static final String HEADER_AUTH = "X-Auth-Token";

    /**
     * Token Secret key
     */
    private static final String SALT =  "apitoken-hide-key";


    /**
     * key
     */
    public static final String KEY_USER_TOKEN_SUBJECT = "access_token";  //
    public static final String KEY_USER_USER_ID = "userId";  //front
    public static final String KEY_USER_USER_NAME = "userName";  // front
    public static final long KEY_USER_EXPIRATION_IN_MS = 30 * 60 * 1000;  // front : 30min


    /**
     * 토큰발행 <-- 토큰 발행시에 options 값에 'expiration' 키값이 있다면
     * 해당 '초' 만큼의 만료시간을 가진다.
     *
     * @param options
     * @param subject
     * @param <T>
     * @return
     */
    public <T> String generateToken(Map<String, String> options, String subject){

        Date now = new Date();

        JwtBuilder builder = Jwts.builder()
                .setHeaderParam("typ", "JWT")
                .setHeaderParam("regDate", System.currentTimeMillis())
                .setIssuedAt(now)
                .setSubject(subject);

        for (String key : options.keySet()) {
            builder.claim(key, options.get(key));
        }

        //seconds unit
        String expiration = options.get("expiration");

        if(StringUtils.isNotEmpty(expiration)) {
            Date validity = new Date(now.getTime()
                    + Long.valueOf(expiration));

            builder.setExpiration(validity);
        }

        String jwt = builder.signWith(SignatureAlgorithm.HS256, this.generateKey())
                .compact();

        return jwt;
    }


    /**
     * 토큰 생성 및 검증을 위한 키값 생성
     * @return
     */
    private byte[] generateKey(){

        byte[] key = null;
        try {
            key = SALT.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            if(log.isInfoEnabled()){
                e.printStackTrace();
            }else{
                log.error("Making JWT Key Error ::: {}", e.getMessage());
            }
        }
        return key;
    }


//    public boolean isUsable(String token) {
//
//        if(StringUtils.isEmpty(token )) {
//            return false;
//        }
//
//        boolean result = true;
//
//        try {
//
//            Jws<Claims> claims = Jwts.parser()
//                    .setSigningKey(this.generateKey())
//                    .parseClaimsJws(token);
//
//        } catch (Exception e) {
//            /*
//            1) ExpiredJwtException :        JWT를 생성할 때 지정한 유효기간 초과할 때.
//            2) UnsupportedJwtException :    예상하는 형식과 일치하지 않는 특정 형식이나 구성의 JWT일 때
//            3) MalformedJwtException :      JWT가 올바르게 구성되지 않았을 때
//            4) SignatureException :         JWT의 기존 서명을 확인하지 못했을 때
//            5) IllegalArgumentException
//             */
//            log.error(e.getMessage());
//            result = false;
//
//            throw e;
//
//        } finally {
//
//            return result;
//        }
//
//    }

//    /**
//     * 현재 보유중인 토큰이 사용가능한 토큰인지를 파악한다.
//     *
//     * @return
//     */
//    public boolean isUsable() {
//
//        return isUsable(getCurrentToken());
//    }


    /**
     * 현재 보유중인 토큰이 상태 체크: throws VAuthException
     * 토큰 없음, 토큰 만료, 토큰 뮤효 구분해줌
     * @return
     */
    public void checkTokenNew() {
        String token = getCurrentToken();
        checkTokenNew(token);
    }


    /**
     * 토큰이 상태 체크: throws VAuthException
     * 토큰 없음, 토큰 만료, 토큰 뮤효 구분해줌
     * @return
     */
    public void checkTokenNew(String token) {

        if( StringUtils.isEmpty(token) ) {
            throw new VAuthException(VAuthException.EnumServerCode.TOKEN_NOT_EXIST);
        }

        try {

            Jws<Claims> claims = Jwts.parser()
                    .setSigningKey(this.generateKey())
                    .parseClaimsJws(token);


            if( claims == null ) {
                throw new VAuthException(VAuthException.EnumServerCode.TOKEN_NOT_VALID);
            }

        } catch (ExpiredJwtException e) {
            throw new VAuthException(VAuthException.EnumServerCode.TOKEN_EXPIRED);
        } catch (Exception e) {
            /*
            1) ExpiredJwtException :        JWT를 생성할 때 지정한 유효기간 초과할 때.
            2) UnsupportedJwtException :    예상하는 형식과 일치하지 않는 특정 형식이나 구성의 JWT일 때
            3) MalformedJwtException :      JWT가 올바르게 구성되지 않았을 때
            4) SignatureException :         JWT의 기존 서명을 확인하지 못했을 때
            5) IllegalArgumentException
             */
            log.error(e.getMessage());
            throw new VAuthException(VAuthException.EnumServerCode.TOKEN_NOT_VALID);
        }
    }


    /**
     * 현재 token 유효한지 체크 no exception
     * @return
     */
    public boolean isUsableNew() {
        String token = getCurrentToken();
        return isUsableNew(token);
    }

    /**
     * token 유효한지 체크 no exception
     * @return
     */
    public boolean isUsableNew(String token) {
        boolean result = false;
        try {
            checkTokenNew(token);
            result = true;
        } catch (VAuthException e) {
            result = false;
        }
        return result;
    }


    /**
     * token 값에서 저장된 정보 가져오기
     * @param key
     * @return
     */
    public String getValue(String key) {

        String token = getCurrentToken();

        return getValue(key, token);
    }

    /**
     * token 값에서 저장된 정보 가져오기
     * @param key
     * @return
     */
    public String getValue(String key, String token) {

        Jws<Claims> claims = Jwts.parser()
                .setSigningKey(generateKey())
                .parseClaimsJws(token);

        Object value = claims.getBody().get(key);

        if( value != null ){
            return value.toString();
        } else {
            return "";
        }
    }


    /**
     * 현재 리퀘스트의 토큰을 구한다.
     * @return
     */
    public String getCurrentToken() {

//        HttpServletRequest request = HttpUtil.getCurrentHttpRequest().get();
        HttpServletRequest request =
                ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
                        .getRequest();
        String token = request.getHeader(TokenService.HEADER_AUTH);

        return token;
    }


}
