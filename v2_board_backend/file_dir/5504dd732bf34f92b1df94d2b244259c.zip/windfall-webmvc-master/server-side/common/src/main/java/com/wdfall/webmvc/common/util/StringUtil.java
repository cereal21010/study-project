package com.wdfall.webmvc.common.util;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;

public class StringUtil {

    private StringUtil(){}


    public static boolean isEmpty(String str) {
        if (str == null || "".equals(str)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 0을 채워준다.
     * @param i
     * @return
     */
    public static String fillZero(int i) {

        if( i < 10) {
            return "0"+i;
        } else {
            return String.valueOf(i);
        }

    }

    /**
     * JSON 스트링 이쁜이 모습으로~
     * @param json
     * @return
     */
    public static String json2PrettyFormat(String json) {

        ObjectMapper mapper = new ObjectMapper();
        try {
            Object jsonObject = mapper.readValue(json, Object.class);
            String prettyJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
            return prettyJson;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 마지막 구분자 삭제
     * @param str
     * @param delimeter
     * @return
     */
    public static String removeLastDelimeter(String str, String delimeter) {

        if( StringUtils.isEmpty(str) ) {
            return str;
        }

        if( str.lastIndexOf(delimeter) == str.length() - delimeter.length() ) {
            return str.substring(0, str.length() - delimeter.length() );
        }

        return str;

    }

    /**
     * 개행 문자열을 br 태그로 변환한다.
     * @param source
     * @return
     */
    public static String newLine2BrTag(String source) {

        String tag = source.replaceAll("(\r\n|\n)", "<br />");

        return tag;
    }

}
