package com.wdfall.webmvc.common.util;

import org.apache.commons.lang3.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Day {


	public static String DATE_TIME_FORMAT = "yyyyMMddHHmmss";
	public static String DATE_FORMAT = "yyyyMMdd";
	public static String YEAR_MONTH_FORMAT = "yyyyMM";


	public static Date clone(Date src) {

		Calendar calendar = Calendar.getInstance();

		calendar.setTime(src);

		return calendar.getTime();
	}
	
	/**
	 * <pre>
     * 현재 날짜를 문자열로 반환한다.
     * 포맷: yyyyMMdd
     * </pre>
     * 
     * @return yyyyMMdd
     */
    public static String getCurrentDateString() {
    	return toStringAsyyyyMMddHHmmss( System.currentTimeMillis() ).substring(0, 8);
    }

	/**
	 * 현재 일자
	 * @return
	 */
	public static String getCurrentDayString() {
		return toStringAsyyyyMMddHHmmss( System.currentTimeMillis() ).substring(6, 8);
	}


	public static long daysDiff(Date from, Date to) {

		long diff = to.getTime() - from.getTime();

		long days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);

		return days;
	}

	public static long minutesDiff(Date from, Date to) {

		long diff = to.getTime() - from.getTime();
		long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);

		return minutes;
	}

	/**
	 * 현재 Date 를 리턴한다.
	 * @return
	 */
	public static Date getCurrentDate() {
		return new Date( System.currentTimeMillis() );
	}

	public static String getCurrentYearString() {
		return toStringAsyyyyMMddHHmmss( System.currentTimeMillis() ).substring(0, 4);
	}

    public static String getCurrentMonthString() {
    	return toStringAsyyyyMMddHHmmss( System.currentTimeMillis() ).substring(4, 6);
    }

	public static String getCurrentDatetimeString() {
		return toStringAsyyyyMMddHHmmss( System.currentTimeMillis() );
	}
    

    public static String now(String format) {
    	Date date = new Date( System.currentTimeMillis() );		
		return toString(date, format);
    }
    
    /**
     * 현재 시간을 스트링(분까지) 반환한다.
     * @return
     */
    public static String getCurrentDateMinString() {
    	Date date = new Date( System.currentTimeMillis() );		
		return toString(date, "yyyyMMddHHmm");
    }
    
    /**
     * 현재 시간을 스트링(분까지) 반환한다.
     * @return
     */
    public static String getCurrentDateMinFormatString() {
    	Date date = new Date( System.currentTimeMillis() );		
		return toString(date, "yyyy.MM.dd HH:mm");
    }
    
    /**
     * 기존 위세이버에서 처리되고 있었던 날짜 포맷 그대로 사용
     * @return
     */
    public static String getCurrentWithOutSymbol() {
		SimpleDateFormat date = new SimpleDateFormat("yyyyMMddkkmmss");
		String dates = date.format(new Date(System.currentTimeMillis()));
		System.out.println(dates);
		return dates;

	}

	/**
	 * 기본인 'yyyy.MM.dd' 형식으로 포매팅
	 * @param src
	 * @return
	 */
	public static String formatDate(String src) {

		if( StringUtils.isEmpty(src) ) {
			return "";
		}

		SimpleDateFormat dt = new SimpleDateFormat("yyyyMMddkkmmss");
		Date date = null;
		try {
			date = dt.parse(src);
		} catch (ParseException e) {
			e.printStackTrace();
			return "";
		}

		return formatDate(date);
	}


	/**
	 * 기본인 'yyyy.MM.dd' 형식으로 포매팅
	 * @return
	 */
	public static String formatDate(Date date) {

		DateFormat output = new SimpleDateFormat("yyyy.MM.dd");
		return output.format(date);
	}

	public static String formatDateMinute(String src) {

		if( StringUtils.isEmpty(src) ) {
			return "";
		}

		SimpleDateFormat dt = new SimpleDateFormat("yyyyMMddkkmmss");
		Date date = null;
		try {
			date = dt.parse(src);
		} catch (ParseException e) {
			e.printStackTrace();
			return "";
		}

		return formatDateMinute(date);
	}

	/**
	 * 기본인 'yyyy.MM.dd' 형식으로 포매팅
	 * @return
	 */
	public static String formatDateMinute(Date date) {

		DateFormat output = new SimpleDateFormat("yyyy.MM.dd hh:mm");
		return output.format(date);
	}


	/**
	 * 기본인 'yyyy.MM.dd' 형식으로 포매팅
	 * @return
	 */
	public static String formatMonth(String src) {

		return src.substring(0, 4) + "." + src.substring(4, 6);
	}

	/**
     *
     * <pre>∂
     * 현재 Date 객체를 가져온다.
     * </pre>
     * 
     * @return 현재 Date 객체
     */
    public Date toDate() {
    	return new Date( this.getTimeInMillis() );
    }
    
    
    /**
     * <pre>
     * 요청된 timestamp 에 대한 Date 객체를 가져온다.
     * timestamp 는 format 과 일치해야 한다.
     * </pre>
     * 
     * @param timestamp - 변환하려는 timestamp
     * @param format - timestamp 의 포맷
     * @return Date객체
     */
    public static Date toDate(String timestamp, String format) {
    	
    	SimpleDateFormat sdf = new SimpleDateFormat(format);
    	Date date = null;
    	try {
			date = sdf.parse(timestamp);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
		
		return date;
    }

	public static Date toDate(String timestamp) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = null;
		try {
			date = sdf.parse(timestamp);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}

		return date;
	}
    
    
	/**
	 * <pre>
	 * 요청된 Date를 문자열로 변환한다.
	 * 포맷: yyyyMMdd
	 * </pre>
	 * @param date 변환하려는 Date
	 * @return 변환된 문자열
	 */
    public static String toDateString(Date date) {
    	return toString(date).substring(0, 8);
    }

	/**
	 * <pre>
	 * 요청된 Date를 문자열로 변환한다.
	 * 포맷: yyyyMMdd
	 * </pre>
	 * @param date 변환하려는 Date
	 * @return 변환된 문자열
	 */
	public static String toHourString(Date date) {
		return toString(date).substring(8, 10);
	}
    
    /**
     * <pre>
     * 요청된 Date를 문자열로 변환한다.
	 * 포맷: yyyyMMddHHmmss
	 * </pre>
	 * 
     * @param date 변환하려는 Date
     * @return 변환된 문자열
     */
    public static String toTimestamp(Date date) {
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
    	String timestamp = "";
    	timestamp = sdf.format(date);
		return timestamp;
    }

    /**
     * <pre>
     * 현재 날짜를 요청된 포맷으로 변환한다.
     * </pre>
     * @param givenFormat - 변환하려는 형식
     * @return 변환된 Date 문자열
     */
    public String toString(String givenFormat) {
    	Date date = new Date( this.getTimeInMillis() );
		DateFormat output = new SimpleDateFormat(givenFormat);
		return output.format(date);
    }
    
    /**
     * 소스 날짜 형식은 '2018-04-15 14:37:06.0' 식으로 전달되어야 함
     * @param src
     * @param givenFormat
     * @return
     * @throws Exception
     */
    public static String toString(String src, String givenFormat) {
    	
    	if( StringUtils.isEmpty(src) ) {
    		return "";
    	}
    	
    	SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
    	Date date = null;
		try {
			date = dt.parse(src);
		} catch (ParseException e) {
			e.printStackTrace();
			return "";
		} 
    	
		DateFormat output = new SimpleDateFormat(givenFormat);
		return output.format(date);
		
    }
    
    /**
     * <pre>
     * 요청된 milliseconds 에 대한
     * Date를 문자열로 변환한다.
     * </pre>
     * 
     * @param millis 현재 시간(밀리세컨드)
     * @return 변환된 문자열
     */
    public static String toStringAsyyyyMMddHHmmss( long millis ) {    	
    	Date date = new Date( millis );		
		return toString(date, "yyyyMMddHHmmss");
    }

	/**
	 * <pre>
	 * 현재 milliseconds 에 대한
	 * Date를 문자열로 변환한다.
	 * </pre>
	 * @return
	 */
	public static String toStringAsyyyyMMddHHmmss() {
		Date date = new Date( System.currentTimeMillis() );
		return toString(date, "yyyyMMddHHmmss");
	}

    /**
     * <pre>
     * 현재 날짜를 milliseconds 로 반환한다.
     * </pre>
     * 
     * @return
     */
    public long getTimeInMillis() {
    	Calendar cal = Calendar.getInstance();
    	return cal.getTimeInMillis();
    }
    
    
    /**
     * <pre>
     * 요청된 Date를 문자열로 반환한다. 
     * 포맷: yyyyMMddHHmmss
     * </pre>
     * 
     * @param date 변환하려는 Date 객체
     * @return 변환된 Date 문자열
     */
    public static String toString(Date date) {		
		return toString(date, "yyyyMMddHHmmss");
    }
    
    
    /**
     * <pre>
     * 요청된 날짜와 포맷을 문자열로 반환한다.
     * </pre>
     * 
     * @param date 변환하려는 Date 객체
     * @param format 변환 형식
     * @return
     */
    public static String toString(Date date, String format) {    	
		DateFormat output = new SimpleDateFormat(format);
		return output.format(date);
    }


	public static boolean isBetween(String today, String from, String to) {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date targetDate = null;
		Date fromDate = null;
		Date toDate = null;
		try {
			targetDate = format.parse(today);
			fromDate = format.parse(from);
			toDate = format.parse(to);
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}
		
		return fromDate.compareTo(targetDate) * targetDate.compareTo(toDate) >= 0;		
	}
	
	/**
	 * 현재 시간(분까지)가 from, to 사이에 있으면 true를 반환한다.
	 * @param from
	 * @param to
	 * @return
	 */
	public static boolean isBetweenByMin(String from, String to) {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmm");
		Date targetDate = null;
		Date fromDate = null;
		Date toDate = null;
		try {
			String today = getCurrentDateMinString();
			targetDate = format.parse(today);
			fromDate = format.parse(from);
			toDate = format.parse(to);
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}
		
		return fromDate.compareTo(targetDate) * targetDate.compareTo(toDate) >= 0;		
	}
    

	public static boolean remainTo(String current, String to) {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmm");
		Date targetDate = null;
		Date toDate = null;
		
		try {
			targetDate = format.parse(current);
			toDate = format.parse(to);
			
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}
		
		return toDate.compareTo(targetDate) >= 0;		
	}
    
	/**
	 * yyyyMMdd String 날짜 값을 Date 포맷팅
	 * @param date
	 * @return
	 */
	public static Date toDateFormmat(String date) {
		Date toDate = null;
		try {
			toDate = new SimpleDateFormat("yyyyMMdd").parse(date);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
		return toDate;
	}


	public static String getDayOfWeek(String src) {

		return getDayOfWeek(toDate(src));
	}

	public static String getDayOfWeek(Date date) {

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		String[] weekDay = { "일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일" };


		int num = cal.get(Calendar.DAY_OF_WEEK)-1;

		return weekDay[num];

	}

	/**
	 * 생년월일 기준 현재 만 나이를 조회한다.
	 * @param birthDate
	 * @return
	 */
	public static int getFullAge(Date birthDate) {

		Date now = new Date();
		long timeBetween = now.getTime() - birthDate.getTime();
		double yearsBetween = timeBetween / 3.15576e+10;
		int age = (int) Math.floor(yearsBetween);

		return age;
	}
}
