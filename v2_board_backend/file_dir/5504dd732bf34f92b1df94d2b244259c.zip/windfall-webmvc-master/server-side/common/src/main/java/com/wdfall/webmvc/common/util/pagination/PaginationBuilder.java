package com.wdfall.webmvc.common.util.pagination;

import java.util.ArrayList;
import java.util.List;

/**
 * 리스트 페이징 처리 유틸
 * 생성자의 전체 데이터 수와, 현재 페이지를 넘기면 자동 계산된다.
 * 첫번째 페이지 번호는 1 이다. ( 0 => 아님)
 */
public class PaginationBuilder {

    /**
     * 페이지에서 사용되는 옵션
     */
    private PaginationOption option = new PaginationOption();

    /**
     * 전체 데이터 개수
     */
    private int totalRows;
    /**
     * 현재 페이지 번호
     */
    private int currentPage;
    /**
     * 다음 블락의 페이지 번호
     */
    private int nextBlockPage;
    public int getNextBlockPage() {
        return this.nextBlockPage;
    }

    /**
     * 이전 블락의 페이지 번호
     */
    private int prevBlockPage;
    public int getPrevBlockPage() {
        return this.prevBlockPage;
    }

    /**
     * 데이터의 시작번호
     * 첫번째 페이지라면 totalRows 값과 동일하다.
     */
    public int getRowIndex() {
        return totalRows - (option.getRowSize() * (this.currentPage - 1) );
    }


    private List<Page> pages;
    /**
     * 총 페이지 수
     */
    public List<Page> getPages() {
        return pages;
    }


    /**
     * 다음 블락 이동가능여부
     * @return
     */
    private boolean nextBlockEnable;
    public boolean isNextBlockEnable() {
        return this.nextBlockEnable;
    }

    /**
     * 이전 블락 이동가능여부
     * @return
     */
    private boolean prevBlockEnable;
    public boolean isPrevBlockEnable() {
        return this.prevBlockEnable;
    }

    public PaginationBuilder(int totalRows, int currentPage, PaginationOption option) {

        if( totalRows > 0 ) {
            this.totalRows = totalRows;
            this.currentPage = currentPage;
            this.option = option;
            calculate();

            this.template = PaginationTemplate.generateSimple(this);
        }
    }



    /**
     * 페이징 계산
     */
    private void calculate() {

        /* 페이지 목록 계산 */
        int totalPages = (int)Math.ceil( this.totalRows / (double)option.getRowSize() );
        int currentBlock = (int)Math.ceil( currentPage / (double)option.getPageSize() );

        int endPage = currentBlock * option.getPageSize();
        int startPage = endPage - option.getPageSize() + 1;
        if( endPage > totalPages ) {
            endPage = totalPages;
        }

        this.pages = new ArrayList<>();
        for( int i = startPage; i <= endPage; i++ ) {
            Page page = new Page(i);
            if( i == currentPage ) {
                page.setCurrentPage(true);
            }
            this.pages.add(page);
        }

        /* 이전, 다음 페이지 이동 가능여부 설정 */
        this.prevBlockEnable = startPage == 1 ? false : true;
        this.nextBlockEnable = endPage * option.getRowSize() >= totalRows ? false : true;

        /* 이전, 다음 블락의 페이지 번호 세팅 */
        this.nextBlockPage =  this.pages.get(this.pages.size()-1).getIndex() + 1;
        this.prevBlockPage = this.pages.get(0).getIndex() == 1 ? 1 : this.pages.get(0).getIndex() - 1;

    }

    /**
     * 생성된 페이징 html 소스
     */
    private String template;
    public String getTemplate() {
        return this.template;
    }


    /**
     * 페이지 처리결과 출력
     * @return
     */
    public String printResult() {

        String msg = "::::페이지 옵션:::: \n";
        msg += "\t=> 한 블록당 페이지 개수 : [" + this.option.getPageSize() + "]\n";
        msg += "\t=> 한 페이지의 데이터 개수 : [" + this.option.getRowSize()    + "]\n\n";

        msg += "::::페이징 처리결과:::::: \n";
        msg += "\t=> 전체 데이터 개수 [" + this.totalRows + "]\n";
        msg += "\t=> 현재 페이지 번호 [" + this.currentPage + "]\n";

        msg += "\t=> 데이터 시작 번호(테이블의 횡번호) [" + this.getRowIndex() + "]\n";

        msg += "\t=> 이전 블락 이동 가능 [" + this.isPrevBlockEnable()+ "]\n";
        msg += "\t=> 이전 블락 페이지 번호 [" + this.getPrevBlockPage()+ "]\n";

        msg += "\t=> 페이지 [" + this.getPages()+ "]\n";

        msg += "\t=> 다음 블락 이동 가능 [" + this.isNextBlockEnable()+ "]\n";
        msg += "\t=> 다음 블락 페이지 번호 [" + this.getNextBlockPage()+ "]\n\n";

        msg += "::::기본 페이징 템플릿 소스:::::: \n";
        msg += this.template;

        return msg;
    }










}
