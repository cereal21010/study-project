package com.wdfall.webmvc.common.domains.board;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.sql.Timestamp;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@SuperBuilder
public class BoardFileVO {

    @Getter@Setter
    private int seq;

    @JsonIgnore
    @Getter@Setter
    private int boardSeq;

    @JsonIgnore
    @Getter@Setter
    private String fieldName;

    @JsonIgnore
    @Getter@Setter
    private String storedPath;

    @JsonIgnore
    @Getter@Setter
    private String storedName;

    @Getter@Setter
    private String originName;

    @Getter@Setter
    private String contentsType;

    @Getter@Setter
    private long contentsLength;

    @JsonIgnore
    @Getter@Setter
    private Timestamp registerTime;

    @JsonIgnore
    @Getter@Setter
    private Timestamp updateTime;

    @JsonProperty("uri")
    public String getUri(){
        //TODO: 접근 URI 생성로직을 주입할 수 있어야 함.
        return "/URIURIURIURIURIURIURIURIURIURIURI/" + storedName;
    }


    @Data
    @Builder(toBuilder = true)
    public static class Search{
        int boardSeq;
        List<Integer> seqs;
        String fieldName;
    }
}
