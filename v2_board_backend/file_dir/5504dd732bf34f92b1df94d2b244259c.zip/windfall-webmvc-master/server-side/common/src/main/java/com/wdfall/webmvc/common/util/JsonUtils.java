package com.wdfall.webmvc.common.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtils {

	/**
	 * jsonarray --> json object
	 * 
	 * @param array
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public static <T> List<T> toList(JSONArray array, Class<T> clazz) throws Exception {
		
		List<T> list = new ArrayList<T>();
        for (int i=0, l=array.length(); i<l; i++){
        		JSONObject jsonObj = (JSONObject)array.get(i);
        		ObjectMapper mapper = new ObjectMapper();
             list.add(mapper.readValue(jsonObj.toString(), clazz));
        }
        return list;
	}
	
	/**
	 * jsonarray --> json object with specified class casting
	 * 
	 * @param obj
	 * @param key
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public static <T> List<T> toList(JSONObject obj, String key, Class<T> clazz) throws Exception {
		JSONArray array = new JSONArray();
		if( obj.has(key) ) {
			array = obj.getJSONArray(key);
		}
		
		return toList(array, clazz);
	}
	
	/**
	 * jsonarray --> json object with specified class casting 
	 * in sts(updated, deleted, created) types
	 * 
	 * @param obj
	 * @param key
	 * @param clazz
	 * @param sts
	 * @return
	 * @throws Exception
	 */
	public static <T> List<T> toList(JSONObject obj, String key, Class<T> clazz, String sts) throws Exception {
		
		JSONArray targetArray = new JSONArray();
		
		if( obj.has(key) ) {
			JSONArray array = obj.getJSONArray(key);
			
			for( int i = 0; i < array.length(); i++ ) {
				JSONObject jsonObj = (JSONObject)array.get(i);
				String dataSts = jsonObj.getString("sts");
				if( StringUtils.isEmpty(dataSts) ) {
					throw new RuntimeException("Data has no 'sts' field");
				}
				if( sts.equals(dataSts) ) {
					targetArray.put(jsonObj);
				}
			}
		}
		return toList(targetArray, clazz);
	}
	
	
	public static <T extends Object> T toObject(JSONObject obj, String key, Class<T> clazz) throws Exception {
		
		ObjectMapper mapper = new ObjectMapper();
		
		JSONObject value = obj.getJSONObject(key);
		
		return mapper.readValue(value.toString(), clazz);
	}
	
	public static <T extends Object> T toObject(String jsonString, Class<T> clazz) throws Exception {
		
		ObjectMapper mapper = new ObjectMapper();
		
		return mapper.readValue(jsonString, clazz);
	}
	
	
	/**
	 * Json string 을 map 형태로 변환
	 * 
	 * @param jsonString
	 * @return
	 * @throws Exception
	 */
	public static Map<String, Object> toMap(String jsonString) {
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> map = null;
		try {
			map = mapper.readValue(jsonString, new TypeReference<Map<String, Object>>(){});
		} catch (IOException e) {

			e.printStackTrace();
		}
		
		return map;
	}

	/**
	 * object를 json으로 변환
	 * @return
	 * @throws Exception
	 */
	public static  String toJson(Object object) {
		try {
			ObjectMapper mapper = new ObjectMapper();

			return mapper.writeValueAsString(object);
		} catch (Exception e) {
			return "";
		}

	}

	/**
	 * object를 json으로 변환: pretty
	 * @return
	 * @throws Exception
	 */
	public static  String toJsonPretty(Object object) {
		try {
			ObjectMapper mapper = new ObjectMapper();

			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		} catch (Exception e) {
			return "";
		}
	}


}
