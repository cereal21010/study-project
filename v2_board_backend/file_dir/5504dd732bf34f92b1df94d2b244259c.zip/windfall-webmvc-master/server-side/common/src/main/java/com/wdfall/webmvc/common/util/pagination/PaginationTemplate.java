package com.wdfall.webmvc.common.util.pagination;

import java.util.List;

/**
 * 페이징 구현 html 소스
 */
public class PaginationTemplate {

    /**
     * 간단한 html 페이징 소스를 구현한다.
     * @param builder
     * @return
     */
    public static String generateSimple(PaginationBuilder builder) {

        String source = "<div class='pagination'>\n";

        List<Page> pages = builder.getPages();

        source += "<ul>\n";
        if( builder.isPrevBlockEnable() ) {
            source += "\t<li onclick='page("+builder.getPrevBlockPage()+")'> ◀︎ </li>\n";
        }
        for( Page page : pages ) {
            source += "\t\t<li onclick='page("+page.getIndex()+")' class='page "+ (page.isCurrentPage() ? "active" : "") +"'>" + page.getIndex() + "</li>\n";
        }
        if( builder.isNextBlockEnable() ) {
            source += "\t<li onclick='page("+builder.getNextBlockPage()+")'> ▶︎ ︎</li>\n";
        }
        source += "</ul>\n";
        source += "</div>";


        String styleSource = getSimpleStyle();

        source = styleSource + source;

        return source;

    }

    /**
     * 가장 기본적인 스타일 소스
     * @return
     */
    private static String getSimpleStyle() {
        String styleSource = "";
        styleSource += "<style>";

        styleSource += ".pagination ul {";
            styleSource += "font-size: 14px;";
            styleSource += "text-align: center;";
            styleSource += "list-style: none;";
            styleSource += "width: 100%;";
            styleSource += "display: flex;";
            styleSource += "justify-content: center;";
        styleSource +="}";

        styleSource += ".pagination ul li{";
            styleSource += "padding: 10px 7px 10px 7px;";
            styleSource += "cursor: pointer;";
        styleSource +="}";

        styleSource += ".pagination ul li.active{";
            styleSource += "font-weight: bold;";
            styleSource += "color: #b73333;";
            styleSource += "cursor: pointer;";
        styleSource +="}";

        styleSource += "</style>";
        return styleSource;
    }
}
