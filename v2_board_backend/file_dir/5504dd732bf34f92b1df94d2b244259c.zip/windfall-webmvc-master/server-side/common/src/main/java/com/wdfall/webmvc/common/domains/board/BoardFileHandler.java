package com.wdfall.webmvc.common.domains.board;

import com.wdfall.webmvc.common.util.DateTimeUtil;
import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.*;


@Slf4j
public class BoardFileHandler {



    public List<BoardFileVO> saveAsBoardFiles(int boardSeq, BoardProperties boardProperties, String fieldName, List<MultipartFile> multipartFiles) {

        BoardProperties.UploadFieldProperty uploadFieldProperty = boardProperties.getDefineUploadField(fieldName);
        if(multipartFiles==null || multipartFiles.size() == 0){
            return Collections.emptyList();
        }

        String path = boardProperties.getFileUploadPath();
        //TODO: 디렉토리 추가 정책 수립.

        List<BoardFileVO> uploadFiles = new ArrayList<>();
        for ( MultipartFile multipartFile :  multipartFiles) {
            if(multipartFile != null){

                _validateUploadFieldProperty(multipartFile, uploadFieldProperty);

                BoardFileVO fileVO = saveAsBoardFile(multipartFile, path, boardSeq, fieldName );
                uploadFiles.add(fileVO);
            }
        }


        return uploadFiles;
    }

    private void _validateUploadFieldProperty(MultipartFile multipartFile, BoardProperties.UploadFieldProperty uploadFieldProperty) {
        if( multipartFile.getSize() > uploadFieldProperty.getLimitSize()  ){
            throw new RuntimeException("File size limit is " + uploadFieldProperty.getLimitSize());
        }

        String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());

        String[] acceptables = uploadFieldProperty.getAcceptableFiles();
        if( acceptables!=null && !Arrays.stream(acceptables).anyMatch(extension::equals) ){
            throw new RuntimeException("Acceptable file extensions " +  Arrays.toString(acceptables) );
        }

        String[] denied = uploadFieldProperty.getDeniedFiles();
        if( denied!=null && Arrays.stream(denied).anyMatch(extension::equals) ){
            throw new RuntimeException("Denied file extensions " +  Arrays.toString(denied) );
        }
    }


    public BoardFileVO saveAsBoardFile(MultipartFile multipartFile, String destPath, int boardSeq, String fieldName) {

        BoardFileVO fileVO = null;

        try{
            File savedFile = save(multipartFile, destPath);
            String storedPath = savedFile.getParentFile().getCanonicalPath();

            fileVO = BoardFileVO.builder()
                    .boardSeq(boardSeq)
                    .fieldName(fieldName)
                    .contentsType(multipartFile.getContentType())
                    .contentsLength(multipartFile.getSize())
                    .originName(multipartFile.getOriginalFilename())
                    .storedPath(storedPath)
                    .storedName(savedFile.getName())
                    .build();

        }catch (IOException e){
            new RuntimeException(e);
        }

        return fileVO;
    }



    private File save(MultipartFile multipartFile, String destPath) throws IOException {

        if(multipartFile==null || destPath == null){
            log.error( "MultipartFile and Path must not null.{} {}", multipartFile, destPath );
            throw new NullPointerException("MultipartFile and Path must not null.");
        }

        String originFileName = multipartFile.getOriginalFilename();
        originFileName = originFileName.substring(originFileName.lastIndexOf("\\") +1);

        long fileSize = multipartFile.getSize();

        String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
        String destFileName = getUniqueFileName(extension);

        File destDir = new File(destPath);
        if(!destDir.exists()){
            destDir.mkdirs();
        }

        File file = new File(destDir, destFileName);
        multipartFile.transferTo(file);

        // 썸네일 이미지 저장. plug-in 형태로 제공.
        /*
        if(isMakeThumbnailImage){
            String thumbnailFileNameSmall = saveFileName + "_s";
            String thumbnailFileNameMedium = saveFileName + "_m";

            File thumbnailFileSmall = new File(directory, thumbnailFileNameSmall);
            File thumbnailFileMedium = new File(directory, thumbnailFileNameMedium);
            VImageUtils.resizeByMaxSize(file, thumbnailFileSmall, SMALL_THUMBNAIL_HEIGHT);
            VImageUtils.resizeByMaxSize(file, thumbnailFileMedium, MEDIUM_THUMBNAIL_HEIGHT);
        }
        */

        return file;
    }

    private static String getUniqueFileName(String ext) {
        ext = ext==null ? "" : "."+ext;

        String nowDate = DateTimeUtil.now("YYYYMMddHHmmss");
        return nowDate + "_" + RandomStringUtils.randomAlphanumeric(3) + ext;
    }

    public void deleteBoardFiles(List<BoardFileVO> boardFiles) {
        for (BoardFileVO boardFile:boardFiles) {
            try{
                File file = new File(boardFile.getStoredPath(), boardFile.getStoredName());
                if(file.isFile()){
                    file.delete();
                }
            }catch (Exception e){
                log.error("Cannot delete file. {}", e);
            }
        }
    }
}
