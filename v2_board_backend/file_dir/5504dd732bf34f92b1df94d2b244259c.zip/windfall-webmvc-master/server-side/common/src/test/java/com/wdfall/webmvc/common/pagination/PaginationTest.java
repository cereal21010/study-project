package com.wdfall.webmvc.common.pagination;

import com.wdfall.webmvc.common.util.pagination.PaginationBuilder;
import com.wdfall.webmvc.common.util.pagination.PaginationOption;
import org.junit.jupiter.api.Test;

public class PaginationTest {


    @Test
    public void testPagination() {
        PaginationOption option = new PaginationOption();
        option.setPageSize(10);
        option.setRowSize(10);
        PaginationBuilder builder = new PaginationBuilder(238, 12, option);

        System.out.println(builder.printResult());
    }

}
