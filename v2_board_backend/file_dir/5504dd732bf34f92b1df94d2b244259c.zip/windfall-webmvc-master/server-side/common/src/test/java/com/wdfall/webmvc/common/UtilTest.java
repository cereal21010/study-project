package com.wdfall.webmvc.common;

import com.wdfall.webmvc.common.util.RandomUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;


@Slf4j
public class UtilTest {

    @Test
    public void testRandomPassword() {
        log.info(RandomUtil.generateRandomPassword());
        log.info(RandomUtil.generateRandomPassword());
        log.info(RandomUtil.generateRandomPassword());
    }
}
