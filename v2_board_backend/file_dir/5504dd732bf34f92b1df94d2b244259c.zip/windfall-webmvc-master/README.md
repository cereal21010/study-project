# 프로젝트 가이드

[프로젝트 용어집](./docs/dictionary.md)

## 서버 모듈 구성 (gradle)
    
- backend-common ( 공통 )
- backend-backoffice ( 관리자 )
- backend-customer ( 사용자 )

## Front 모듈 구성 (npm)     
- frontend-backoffice ( 관리자 화면)
- frontend-customer ( 사용자 )

## 이슈 관리
- 이슈유형 
    - Task
    - Bug
    - 개선
    
## GIT
- TODO: 코멘트 규칙 정하기.  
  
- 이슈 번호가 있다면 이슈 번호 붙이기
```
ex) [FIX][#1232] 블라블라 버그 수정
```
 
- 제목은 간단하게 두줄이내로 목적을 설명
``` 
ex) [ADD] 프로젝트 가이드 추가
```
    
- 상세 내용이 있다면 제목 한줄 띄고 작성 (제목과 본문 구분을 위해)
```
ex) [ADD] 프로젝트 가이드 추가
      프로젝트를 하기 위해 알아야 할 내용과 컨벤션 등 규칙정의를 위한 가이드 추가합니다.
```
  
## 코드공유 및 리뷰
     
* 메일이나 슬랙등으로 내용 공유하기 ( 알아두면 좋을 이슈나 공통사용 할 컴포넌트를 만들었거나 등등 알아서)
    
* 글로 설명이 어렵다면 10분이내(요점만 짧게)로 코드리뷰 진행하기 ( Story정도의 일감 완료 시?)
    * 원하는 부분의 리뷰가 있다면 요청가능.
    * 어떤 부분인지 공유 후 듣기를 원하는 사람만 진행
    * 리뷰 일정은 리뷰 해주는사람에게 맞추기 
        
         
* 다른 사람이 Commit한 내용 읽기! ( 여유가 있다면 소스까지 살펴보기 ) 

## API URI 정의
* GET 
    * 고정 인자의 경우 Path-Var로 정의.
    ```
    /api/detail/3
    ``` 
    * 가변 인자의 경우 Querh String으로 정의.
    ```
    /api/list/search?mykey=xxx&yourkey&xxx&orderby=xxx
    ```


* DELETE
    * 고정 인자의 경우 Path-Var로 정의.
    ```
    /api/delete/3
    ```
        
    * 가변 인자의 경우 Querh String으로 정의.
    ```
    /api/delete?mykey=xxx&yourkey
    ```
        
* POST
    * Path-Var만 필요한 경우는 그대로 적용.
    ```
        (O) /api/memo/delete/3
             
        (X) /api/memo/delete
             {seq:3}
    ```
  
    * PK를 넘기는 경우에는 Path-Var 적용
    ```
        (O) /api/memo/update/MEMBER/3
            {contents:'this is memo.'}
        
        (X) /api/memo/update/MEMBER
            {pk:3, contents:'this is memo.'}
    ```

## 코딩 컨밴션
[Coding Convection](./docs/coding-convention.md)






------------------

# F2F - FrontEnd
### Package setup
```
cd {PROJECT_HOME}/front-side
npm install
```

### Local 개발서버 구동
```
cd {PROJECT_HOME}/front-side
npm run serve
```

### Build
```
cd {PROJECT_HOME}/front-side
npm run build
```

### Directory 
- public
    - 컴파일 되지 않는 정적 리소스
- src
    - views

### 라우팅 경로 네이밍
- 목록 : /member/list
- 상세 : /member/view/123
- 수정입력: /member/update/123
- 신규입력: /member/insert/123
        