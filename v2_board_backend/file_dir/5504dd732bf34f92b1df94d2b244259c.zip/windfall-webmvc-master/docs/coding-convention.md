
### 명명규칙

    * JAVA 
        * google java convention
        [https://google.github.io/styleguide/javaguide.html]
        
    * API
        * GET/POST만 사용 (PUT/DELETE 사용하지않음)
        * 계층관계를 나타낼 때 슬래시 구분자를 사용
          * ex) /api/member/52
          * ex) /api/member/52/my-pet  
        * 언더바(_) 문자 사용하지 않음
        * 소문자로 하고 하이픈(-)문자를 사용 
          * ex) /api/member/list/download-to-excel  

### 상수 선언 규칙
    * 가변적인 코드들은 db에 보관.
    * 가변적인 코드들의 parent 코드값은 java에서 상수로 선언.
    
    * 절대 변할 일 없는 상수코드들은 java에서 선언.
    * 상수코드의 text 값은 bundle 로 관리.
